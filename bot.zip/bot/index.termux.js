const { spawn } = require('child_process');
const path = require('path');
const fs = require('fs');
const os = require('os');

require('./config');

const bot_ku = 'VynaaMD';

let isRunning = false;
let currentProcess = null;
let connectionErrorCount = 0;
let connectionErrorTimer = null;

function resetConnectionErrors() {
  connectionErrorCount = 0;
}

function forceRestart(reason) {
  console.log(`⚠️  Auto-restart: ${reason}`);
  connectionErrorCount = 0;
  if (currentProcess) {
    try { currentProcess.kill(); } catch(e) {}
  }
  isRunning = false;
  setTimeout(() => start('main.js'), 2000);
}

function start(file) {
  if (isRunning) return;
  isRunning = true;

  const args = [path.join(__dirname, file), ...process.argv.slice(2)];
  const p = spawn(process.argv[0], args, {
    stdio: ["inherit", "pipe", "pipe", "ipc"],
  });
  currentProcess = p;

  // Reset connection error count every hour
  if (connectionErrorTimer) clearInterval(connectionErrorTimer);
  connectionErrorTimer = setInterval(resetConnectionErrors, 60 * 60 * 1000);

  // Monitor stdout & stderr for connection errors — auto-restart bila 3x error
  function checkConnectionError(data) {
    process.stdout.write(data);
    const msg = data.toString();
    if (msg.includes('Connection Closed') || msg.includes('connection failure') || msg.includes('Stream Errored')) {
      connectionErrorCount++;
      console.log(`⚠️  Connection error #${connectionErrorCount} dikesan`);
      if (connectionErrorCount >= 3) {
        forceRestart('Terlalu banyak connection error, restart automatik...');
      }
    }
  }

  p.stdout.on('data', checkConnectionError);
  p.stderr.on('data', (data) => {
    process.stderr.write(data);
    const msg = data.toString();
    if (msg.includes('Connection Closed') || msg.includes('connection failure') || msg.includes('Stream Errored')) {
      connectionErrorCount++;
      if (connectionErrorCount >= 3) {
        forceRestart('Terlalu banyak connection error, restart automatik...');
      }
    }
  });

  p.on("message", (data) => {
    switch (data) {
      case "reset":
        p.kill();
        isRunning = false;
        start.apply(this, arguments);
        break;
      case "uptime":
        p.send(process.uptime());
        break;
    }
  });

  p.on("exit", (code) => {
    isRunning = false;
    currentProcess = null;
    console.error(`Exited with code: ${code}. Restart dalam 3 saat...`);
    setTimeout(() => start('main.js'), 3000);
  });

  p.on("error", (err) => {
    console.error(`Error: ${err}`);
    if (currentProcess) try { currentProcess.kill(); } catch(e) {}
    isRunning = false;
    currentProcess = null;
    setTimeout(() => start("main.js"), 3000);
  });

  console.log(`🖥️  ${os.type()} ${os.release()} - ${os.arch()}`);
  const ramInGB = os.totalmem() / (1024 * 1024 * 1024);
  console.log(`💾 Total RAM: ${ramInGB.toFixed(2)} GB`);
  const freeRamInGB = os.freemem() / (1024 * 1024 * 1024);
  console.log(`💽 Free RAM: ${freeRamInGB.toFixed(2)} GB`);
  console.log(`🌸 ${bot_ku} — Bot by VynaaValerie`);
  setInterval(() => {}, 1000);
}

process.on('unhandledRejection', (reason) => {
  console.error(`Unhandled rejection: ${reason}`);
});

process.on('SIGINT', () => {
  console.log('\n👋 Bot dihentikan.');
  if (currentProcess) try { currentProcess.kill(); } catch(e) {}
  process.exit(0);
});

const tmpDir = './tmp';
if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir);

console.log('');
console.log('╔══════════════════════════════════╗');
console.log('║     VynaaMD - WhatsApp Bot       ║');
console.log('║       by VynaaValerie 🌸          ║');
console.log('╚══════════════════════════════════╝');
console.log('');

start("main.js");
