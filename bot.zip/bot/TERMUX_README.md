# VynaaMD Bot — Cara Pasang di Termux

## Langkah 1 — Install Termux & buka

Download Termux dari F-Droid (bukan Play Store):
https://f-droid.org/packages/com.termux/

## Langkah 2 — Install pakej yang diperlukan

```bash
pkg update -y && pkg upgrade -y
pkg install nodejs git -y
```

## Langkah 3 — Pindahkan fail bot ke Termux

**Cara A — Guna Bluetooth/USB:**
Pindahkan fail `VynaaMD-Termux.tar.gz` ke folder Download telefon.

**Cara B — Guna Google Drive/Telegram:**
Upload fail, download dalam telefon.

Pastu dalam Termux:
```bash
cd /sdcard/Download
tar -xzf VynaaMD-Termux.tar.gz
mv bot ~/VynaaMD
cd ~/VynaaMD
```

## Langkah 4 — Jalankan script install

```bash
bash install.sh
```

Script ini akan install semua pakej yang diperlukan secara automatik.

## Langkah 5 — Jalankan bot

```bash
node index.termux.js
```

## Langkah 6 — Pair dengan WhatsApp

- Bila bot start, masukkan nombor telefon (contoh: `601156606229`)
- Tekan Enter
- Bot akan bagi **Pairing Code** (contoh: `VYNA-BOTS`)
- Buka WhatsApp > ⋮ Menu > **Peranti Tertaut** > **Taut Peranti**
- Masukkan kod pairing

## Jalankan bot di background (tak tutup bila close Termux)

```bash
# Install screen
pkg install screen -y

# Buat session baru
screen -S vynabot

# Jalankan bot
node index.termux.js

# Untuk minimize (bot still running):
# Tekan Ctrl + A, lepas, pastu tekan D

# Untuk balik semula:
screen -r vynabot
```

## Ciri Auto-Restart

Bot ada **auto-restart** — bila WhatsApp disconnect 3 kali dalam sejam, bot akan restart sendiri tanpa perlu awak buat apa-apa.

## Notes Penting

- Folder `sessions/` simpan maklumat log in — **JANGAN DELETE** atau kena pair semula
- Konfigurasi ada di `config.js`
- Semua plugin ada dalam `plugins/`
- Log bot tersimpan dalam `bot.log` (kalau guna nohup)

## Lihat log bila run di background

```bash
tail -f bot.log
```
