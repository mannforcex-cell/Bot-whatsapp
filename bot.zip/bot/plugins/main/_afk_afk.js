let handler = async (m, { text }) => {
  let user = global.db.data.users[m.sender]
  user.afk = + new Date
  user.afkReason = text
  m.reply(`@${m.sender.split`@`[0]} sedang AFK ${text ? '\nSebab : ' + text : 'Tanpa Sebab'}
`)
}
handler.help = ['afk [sebab]']
handler.tags = ['main']
handler.command = /^afk$/i

module.exports = handler
