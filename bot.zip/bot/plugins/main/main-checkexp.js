let fetch = require('node-fetch')
let handler = async (m, { text }) => {
  if (!text) throw `Masukkan Username di Laman Web`
  try {
    let api = await fetch(`https://api.vtech.biz.id/api/checkexp?username=${text}`)
    let body = await api.text()
    m.reply(body)
  } catch (e) {
    console.log(e)
    m.reply('Username tidak berdaftar!')
  }
}
handler.command = handler.help = ['checkexp', 'cekexp'];
handler.tags = ['main'];
handler.private = true
module.exports = handler;
