process.env.TZ = 'Asia/Kuala_Lumpur'

const axios = require('axios')
let sharp
try { sharp = require('sharp') } catch(e) { sharp = null }
const moment = require('moment-timezone')

let arrayMenu = [
  'all',
  'ai',
  'main',
  'downloader',
  'database',
  'rpg',
  'rpgG',
  'sticker',
  'advanced',
  'xp',
  'fun',
  'game',
  'github',
  'group',
  'image',
  'nsfw',
  'info',
  'internet',
  'islam',
  'kerang',
  'maker',
  'news',
  'owner',
  'voice',
  'quotes',
  'store',
  'stalk',
  'shortlink',
  'tools',
  'anonymous',
  'nokos'
]

const allTags = {
  all: 'SEMUA MENU',
  ai: 'AI',
  main: 'UTAMA',
  downloader: 'MUAT TURUN',
  database: 'PANGKALAN DATA',
  rpg: 'RPG',
  rpgG: 'RPG GUILD',
  sticker: 'PELEKAT',
  advanced: 'LANJUTAN',
  xp: 'XP & TAHAP',
  fun: 'HIBURAN',
  game: 'PERMAINAN',
  github: 'GITHUB',
  group: 'KUMPULAN',
  image: 'IMEJ',
  nsfw: 'NSFW',
  info: 'MAKLUMAT',
  internet: 'INTERNET',
  islam: 'ISLAM',
  kerang: 'KERANG AJAIB',
  maker: 'PEMBUAT',
  news: 'BERITA',
  owner: 'PEMILIK',
  voice: 'SUARA',
  quotes: 'PETIKAN',
  store: 'KEDAI',
  stalk: 'CARI INFO',
  shortlink: 'PAUTAN PENDEK',
  tools: 'ALATAN',
  anonymous: 'TANPA NAMA',
  nokos: 'NOKOS OTP'
}

const THUMB_URL = 'https://g.top4top.io/p_3788rcsmz1.jpeg'

let cachedThumb = null

async function getThumbnail() {
  if (cachedThumb) return cachedThumb

  try {
    const res = await axios.get(THUMB_URL, {
      responseType: 'arraybuffer',
      timeout: 10000
    })

    cachedThumb = await sharp(Buffer.from(res.data))
      .resize(500, 300, { fit: 'cover' })
      .jpeg({ quality: 85 })
      .toBuffer()

  } catch (e) {
    cachedThumb = null
  }

  return cachedThumb
}

let handler = async (m, { conn, usedPrefix, args }) => {
  try {
    let user = global.db.data.users[m.sender] || {}

    let level = user.level || 0
    let limit = user.limit || 0
    let name = m.pushName || 'Pengguna'

    let input = (args[0] || '').toLowerCase()

    let now = moment().tz('Asia/Kuala_Lumpur')
    let tarikh = now.format('DD/MM/YYYY')
    let masa = now.format('HH:mm:ss')

    let uptime = clockString(process.uptime() * 1000)

    let thumb = await getThumbnail()

    let plugins = Object.values(global.plugins)
      .filter(v => v.help && !v.disabled)
      .map(v => {
        return {
          help: Array.isArray(v.help) ? v.help : [v.help],
          tags: Array.isArray(v.tags) ? v.tags : [v.tags],
          premium: v.premium,
          limit: v.limit,
          customPrefix: v.customPrefix
        }
      })

    if (!input) {

      let categoryText = ''

      for (let tag of arrayMenu) {
        if (tag === 'all') continue
        categoryText += `│◦ ${usedPrefix}menu ${tag}\n`
      }

      let text = `
╭━━━〔 ManFXOffice 〕━━━⬣
│
│◦ Hai ${name}
│◦ Awalan : ${usedPrefix}
│◦ Tahap : ${level}
│◦ Had : ${limit}
│
│◦ Tarikh : ${tarikh}
│◦ Masa : ${masa} MYT
│◦ Masa Aktif : ${uptime}
│
├─〔 SENARAI MENU 〕
${categoryText}│
├─〔 MAKLUMAT 〕
│◦ Taip ${usedPrefix}menu all
│◦ Untuk melihat semua menu
│
╰━━━〔 ManFXOffice 〕━━⬣
`.trim()

      if (thumb) {
        return conn.sendMessage(m.chat, {
          image: thumb,
          caption: text,
          mentions: [m.sender]
        }, { quoted: m })
      }

      return conn.sendMessage(m.chat, {
        text,
        mentions: [m.sender]
      }, { quoted: m })
    }

    if (!allTags[input]) {
      return m.reply(`
Menu *${input}* tidak dijumpai.

Taip:
${usedPrefix}menu
`.trim())
    }

    const renderCategory = (tag) => {

      let cmds = plugins.filter(v => v.tags.includes(tag))

      let txt = `
╭━━━〔 ${allTags[tag]} 〕━━━⬣
│
`.trim()

      if (cmds.length < 1) {
        txt += `\n│◦ Tiada menu`
      }

      for (let cmd of cmds) {
        for (let h of cmd.help) {
          let isPremium = cmd.premium ? ' Ⓟ' : ''
          let isLimit = cmd.limit ? ' Ⓛ' : ''
          txt += `\n│◦ ${cmd.customPrefix ? '' : usedPrefix}${h}${isLimit}${isPremium}`
        }
      }

      txt += `\n│\n╰━━━━━━━━━━━━⬣\n`

      return txt
    }

    let result = `
╭━━━〔 ManFXOffice 〕━━━⬣
│
│◦ Pengguna : ${name}
│◦ Tahap : ${level}
│◦ Had : ${limit}
│◦ Masa : ${masa} MYT
│
╰━━━━━━━━━━━━⬣

`.trim()

    if (input === 'all') {
      for (let tag of arrayMenu) {
        if (tag === 'all') continue
        result += '\n\n' + renderCategory(tag)
      }
    } else {
      result += '\n\n' + renderCategory(input)
    }

    result += `

> Ⓛ = guna had
> Ⓟ = premium sahaja
`.trim()

    if (thumb) {
      return conn.sendMessage(m.chat, {
        image: thumb,
        caption: result,
        mentions: [m.sender]
      }, { quoted: m })
    }

    await conn.sendMessage(m.chat, {
      text: result,
      mentions: [m.sender]
    }, { quoted: m })

  } catch (e) {
    console.log(e)
    m.reply('Menu error, cuba lagi.')
  }
}

handler.help = ['menu', 'help']
handler.tags = ['main']
handler.command = /^(menu|help)$/i

module.exports = handler

function clockString(ms) {
  if (isNaN(ms)) return '--'

  let h = Math.floor(ms / 3600000)
  let m = Math.floor(ms / 60000) % 60
  let s = Math.floor(ms / 1000) % 60

  return [h, m, s]
    .map(v => v.toString().padStart(2, 0))
    .join(':')
}
