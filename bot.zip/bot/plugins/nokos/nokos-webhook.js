const axios = require('axios')

const BASE = () => global.nokos_base
const TOKEN = () => global.nokos_token
const headers = () => ({ Authorization: `Bearer ${TOKEN()}` })

let handler = async (m, { conn, command, text, usedPrefix }) => {
  try {
    switch (command) {
      case 'nokoswebhook': {
        await conn.reply(m.chat, global.wait, m)
        const { data: res } = await axios.get(`${BASE()}/webhook`, { headers: headers() })
        if (!res.success) throw res.error?.message || 'Gagal mengambil konfigurasi webhook'
        const d = res.data
        let teks = `╭━━━〔 🔗 KONFIGURASI WEBHOOK 〕━━━⬣\n│\n`
        teks += `│ 🌐 URL    : ${d.webhook_url || '_(belum diset)_'}\n`
        teks += `│ 🔑 Secret : ${d.webhook_secret ? d.webhook_secret.substring(0, 8) + '••••••••' : '_(belum ada)_'}\n│\n`
        teks += `╰━━━〔 VTechOTP Webhook 〕━━⬣\n\n`
        teks += `💡 Ubah URL : *${usedPrefix}nokossetwh <url>*\n`
        teks += `🧪 Test     : *${usedPrefix}nokostestwh*`
        await conn.reply(m.chat, teks, m)
        break
      }

      case 'nokossetwh': {
        if (!text) return conn.reply(m.chat,
          `❌ Masukkan URL webhook!\n\nContoh: *${usedPrefix}nokossetwh https://yoursite.com/webhook*\n\n💡 Kosongkan URL untuk menghapus webhook:\n*${usedPrefix}nokossetwh hapus*`, m)
        await conn.reply(m.chat, global.wait, m)
        const webhook_url = text.trim() === 'hapus' ? '' : text.trim()
        const { data: res } = await axios.patch(`${BASE()}/webhook`,
          { webhook_url },
          { headers: { ...headers(), 'Content-Type': 'application/json' } }
        )
        if (!res.success) throw res.error?.message || 'Gagal mengubah webhook'
        const d = res.data
        let teks = `╭━━━〔 ✅ WEBHOOK DIPERBARUI 〕━━━⬣\n│\n`
        teks += `│ 🌐 URL    : ${d.webhook_url || '_(dihapus)_'}\n`
        teks += `│ 🔑 Secret : ${d.webhook_secret ? d.webhook_secret.substring(0, 8) + '••••••••' : '_(belum ada)_'}\n│\n`
        teks += `╰━━━〔 VTechOTP Webhook Updated 〕━━⬣`
        await conn.reply(m.chat, teks, m)
        break
      }

      case 'nokostestwh': {
        await conn.reply(m.chat, global.wait, m)
        const { data: res } = await axios.post(`${BASE()}/webhook/test`, {},
          { headers: { ...headers(), 'Content-Type': 'application/json' } }
        )
        if (!res.success) throw res.error?.message || 'Gagal mengirim test webhook'
        const d = res.data
        await conn.reply(m.chat,
          `╭━━━〔 🧪 TEST WEBHOOK 〕━━━⬣\n│\n` +
          `│ 📡 Status Code : *${d.status_code}*\n` +
          `│ ✅ Hasil       : ${d.status_code === 200 ? 'Webhook aktif & merespons!' : 'Ada masalah pada endpoint'}\n│\n` +
          `╰━━━〔 VTechOTP Webhook Test 〕━━⬣`, m)
        break
      }
    }
  } catch (e) {
    const msg = e?.response?.data?.error?.message || e?.message || e
    conn.reply(m.chat, `❌ *Error:* ${msg}`, m)
  }
}

handler.help = [
  'nokoswebhook',
  'nokossetwh <url>',
  'nokostestwh'
]
handler.tags = ['nokos']
handler.command = /^(nokoswebhook|nokossetwh|nokostestwh)$/i
handler.owner = true

module.exports = handler
