const axios = require('axios')

const BASE = () => global.nokos_base
const TOKEN = () => global.nokos_token
const headers = () => ({ Authorization: `Bearer ${TOKEN()}` })

let handler = async (m, { conn, command, args, usedPrefix }) => {
  try {
    switch (command) {
      case 'nokosnegara': {
        await conn.reply(m.chat, global.wait, m)
        const { data: res } = await axios.get(`${BASE()}/catalog/countries`, { headers: headers() })
        if (!res.success) throw res.error?.message || 'Gagal mengambil data negara'
        const list = res.data
        let teks = `╭━━━〔 🌍 DAFTAR NEGARA NOKOS 〕━━━⬣\n│\n`
        for (const n of list) {
          teks += `│ ${n.emoji || '🏳️'} *${n.name}* (${n.code})\n`
          teks += `│  • ID Negara : ${n.id}\n`
          teks += `│  • Dial Code : ${n.dial_code}\n`
          teks += `│  • Status   : ${n.active ? '✅ Aktif' : '❌ Nonaktif'}\n│\n`
        }
        teks += `╰━━━〔 Total: ${list.length} negara 〕━━⬣`
        await conn.reply(m.chat, teks, m)
        break
      }

      case 'nokoslayanan': {
        await conn.reply(m.chat, global.wait, m)
        const params = args[0] ? { country_id: args[0] } : {}
        const { data: res } = await axios.get(`${BASE()}/catalog/services`, { headers: headers(), params })
        if (!res.success) throw res.error?.message || 'Gagal mengambil data layanan'
        const list = res.data
        let teks = `╭━━━〔 📱 DAFTAR LAYANAN NOKOS 〕━━━⬣\n│\n`
        if (args[0]) teks = `╭━━━〔 📱 LAYANAN (Negara ID: ${args[0]}) 〕━━━⬣\n│\n`
        for (const s of list) {
          teks += `│ *${s.name}* (${s.code})\n`
          teks += `│  • ID Platform : ${s.id}\n`
          teks += `│  • Status      : ${s.active ? '✅ Aktif' : '❌ Nonaktif'}\n│\n`
        }
        teks += `╰━━━〔 Total: ${list.length} layanan 〕━━⬣\n\n`
        teks += `💡 Filter per negara: *${usedPrefix}nokoslayanan <id_negara>*`
        await conn.reply(m.chat, teks, m)
        break
      }

      case 'nokosproduk': {
        await conn.reply(m.chat, global.wait, m)
        const params = {}
        if (args[0]) {
          const parts = args.join(' ').split(',').map(s => s.trim())
          if (parts[0]) params.country_id = parts[0]
          if (parts[1]) params.platform_id = parts[1]
          if (parts[2]) params.limit = parts[2]
          if (parts[3]) params.sort = parts[3]
        }
        params.limit = params.limit || 50
        const { data: res } = await axios.get(`${BASE()}/catalog/products`, { headers: headers(), params })
        if (!res.success) throw res.error?.message || 'Gagal mengambil data produk'
        const list = res.data
        const meta = res.meta || {}
        let teks = `╭━━━〔 🛒 DAFTAR PRODUK NOKOS 〕━━━⬣\n│\n`
        for (const p of list) {
          teks += `│ *${p.name}*\n`
          teks += `│  • ID Produk   : ${p.id}\n`
          teks += `│  • ID Negara   : ${p.country_id}\n`
          teks += `│  • ID Platform : ${p.platform_id}\n`
          teks += `│  • Tersedia    : ${p.available} nomor\n`
          teks += `│  • Harga       : Rp ${p.price?.toLocaleString('id-ID')}\n`
          teks += `│  • Status      : ${p.active ? '✅ Aktif' : '❌ Nonaktif'}\n│\n`
        }
        teks += `╰━━━〔 Tampil: ${list.length}${meta.count ? ` dari ${meta.count}` : ''} produk 〕━━⬣\n\n`
        teks += `💡 Filter: *${usedPrefix}nokosproduk <country_id>,<platform_id>*\n`
        teks += `💡 Beli  : *${usedPrefix}belinokos <country_id>,<platform_id>,<product_id>*`
        await conn.reply(m.chat, teks, m)
        break
      }

      case 'nokoskurs': {
        await conn.reply(m.chat, global.wait, m)
        const pair = args[0] || 'USD/IDR'
        const { data: res } = await axios.get(`${BASE()}/catalog/exchange-rate`, { headers: headers(), params: { pair } })
        if (!res.success) throw res.error?.message || 'Gagal mengambil kurs'
        const d = res.data
        let teks = `╭━━━〔 💱 KURS MATA UANG 〕━━━⬣\n│\n`
        teks += `│ Pair  : *${d.pair}*\n`
        teks += `│ Base  : ${d.base_currency}\n`
        teks += `│ Quote : ${d.quote_currency}\n`
        teks += `│ Rate  : *${d.rate?.toLocaleString('id-ID')}*\n│\n`
        teks += `╰━━━〔 VTechOTP Exchange Rate 〕━━⬣`
        await conn.reply(m.chat, teks, m)
        break
      }
    }
  } catch (e) {
    const msg = e?.response?.data?.error?.message || e?.message || e
    conn.reply(m.chat, `❌ *Error:* ${msg}`, m)
  }
}

handler.help = [
  'nokosnegara',
  'nokoslayanan [id_negara]',
  'nokosproduk [country_id,platform_id]',
  'nokoskurs [pair]'
]
handler.tags = ['nokos']
handler.command = /^(nokosnegara|nokoslayanan|nokosproduk|nokoskurs)$/i
handler.owner = true

module.exports = handler
