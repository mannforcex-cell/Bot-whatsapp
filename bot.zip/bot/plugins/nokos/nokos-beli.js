const axios = require('axios')

const BASE = () => global.nokos_base
const TOKEN = () => global.nokos_token
const hdrs = () => ({ Authorization: `Bearer ${TOKEN()}` })
const jsonHdrs = () => ({ ...hdrs(), 'Content-Type': 'application/json' })

async function getCountries() {
  const { data } = await axios.get(`${BASE()}/catalog/countries`, { headers: hdrs() })
  return data.data || []
}

async function getServices() {
  const { data } = await axios.get(`${BASE()}/catalog/services`, { headers: hdrs() })
  return data.data || []
}

async function getProducts(country_id, platform_id) {
  const { data } = await axios.get(`${BASE()}/catalog/products`, {
    headers: hdrs(),
    params: { country_id, platform_id, sort: 'available_desc', limit: 1000 }
  })
  return data.data || []
}

function findCountry(countries, arg) {
  if (/^\d+$/.test(arg)) return countries.find(c => c.id === parseInt(arg))
  const q = arg.toLowerCase()
  return countries.find(c =>
    c.name.toLowerCase().includes(q) ||
    c.code.toLowerCase() === q ||
    (q === 'indo' && c.code === 'ID') ||
    (q === 'indonesia' && c.code === 'ID')
  )
}

function findPlatform(services, arg) {
  if (/^\d+$/.test(arg)) return services.find(s => s.id === parseInt(arg))
  const q = arg.toLowerCase()
  return services.find(s =>
    s.name.toLowerCase().includes(q) ||
    s.code.toLowerCase() === q ||
    (q === 'wa' && s.code === 'wa')
  )
}

const RETRYABLE_CODES = new Set(['NOT_FOUND', 'PROVIDER_ERROR', 'SERVICE_UNAVAILABLE'])

async function tryOrderWithFallback(candidates) {
  const errors = []
  for (const prod of candidates) {
    try {
      const { data: res } = await axios.post(`${BASE()}/orders/create`,
        { product_id: prod.id },
        { headers: jsonHdrs() }
      )
      if (res.success) return { res, product: prod, attempts: errors.length + 1 }
      const code = res.error?.code
      const msg = res.error?.message || 'Gagal'
      if (RETRYABLE_CODES.has(code)) { errors.push(msg); continue }
      throw msg
    } catch (e) {
      if (typeof e === 'string') throw e
      const code = e?.response?.data?.error?.code
      const msg = e?.response?.data?.error?.message || e?.message || 'Gagal'
      if (RETRYABLE_CODES.has(code)) { errors.push(msg); continue }
      throw msg
    }
  }
  const tried = candidates.length
  const lastErr = errors[errors.length - 1] || 'Provider error'
  throw `Semua ${tried} produk dicoba namun gagal.\nError terakhir: _${lastErr}_\n\nKemungkinan penyebab:\n• Saldo tidak cukup\n• Provider sedang gangguan\n• Coba beberapa menit lagi`
}

async function sendOrderSuccess(conn, m, res, info, attempts, usedPrefix) {
  const orders = res.data?.orders || []
  const failed = res.data?.failed_count || 0
  let teks = `╭━━━〔 ✅ ORDER BERHASIL DIBUAT 〕━━━⬣\n│\n`
  if (info) {
    teks += `│ 🌍 Negara   : ${info.country.emoji || ''} ${info.country.name}\n`
    teks += `│ 📱 Platform : ${info.platform.name}\n`
    teks += `│ 🛒 Produk   : ${info.product?.name || '-'}\n`
    teks += `│ 💰 Harga    : Rp ${info.product?.price?.toLocaleString('id-ID')}\n`
    if (attempts > 1) teks += `│ ♻️ Fallback  : percobaan ke-${attempts}\n`
    teks += `│\n`
  }
  for (const o of orders) {
    teks += `│ 🆔 ID Order : *${o.id}*\n`
    teks += `│ 📞 Nomor   : *${o.phone_number}*\n`
    teks += `│ ⏳ Status  : ${o.status}\n`
    teks += `│ ⌛ Expired : ${new Date(o.expires_at).toLocaleString('id-ID')}\n│\n`
  }
  if (failed > 0) teks += `│ ⚠️ Gagal: ${failed} order\n│\n`
  teks += `╰━━━〔 Gunakan ID untuk cek OTP 〕━━⬣\n\n`
  teks += `📌 Cek OTP  : *${usedPrefix}nokoscekorder <id>*\n`
  teks += `❌ Cancel   : *${usedPrefix}nokoscancel <id>*\n`
  teks += `🏁 Selesai  : *${usedPrefix}nokosfinish <id>*`
  await conn.reply(m.chat, teks, m)
}

let handler = async (m, { conn, command, text, usedPrefix }) => {
  try {
    switch (command) {
      case 'belinokos': {
        if (!text) {
          return conn.reply(m.chat,
            `❓ *Cara Beli Nomor Virtual (NOKOS)*\n\n` +
            `*Format 1 — langsung pakai product_id:*\n` +
            `${usedPrefix}belinokos <product_id>\n` +
            `Contoh: ${usedPrefix}belinokos 142\n\n` +
            `*Format 2 — otomatis stok terbanyak:*\n` +
            `${usedPrefix}belinokos <negara>,<platform>\n` +
            `Contoh: ${usedPrefix}belinokos indo,whatsapp\n` +
            `Contoh: ${usedPrefix}belinokos indonesia,wa\n\n` +
            `*Format 3 — dengan rank urutan:*\n` +
            `${usedPrefix}belinokos <negara>,<platform>,<rank>\n` +
            `Contoh: ${usedPrefix}belinokos indo,whatsapp,1\n\n` +
            `ℹ️ Cek ID negara: *${usedPrefix}nokosnegara*\n` +
            `ℹ️ Cek ID platform: *${usedPrefix}nokoslayanan*\n` +
            `ℹ️ Cek produk: *${usedPrefix}nokosproduk*\n\n` +
            `♻️ Rolling fallback aktif — jika satu produk gagal, otomatis coba produk lain!`, m)
        }

        await conn.reply(m.chat, global.wait, m)

        const parts = text.trim().split(',').map(s => s.trim())

        // Format 1: single product_id
        if (parts.length === 1 && /^\d+$/.test(parts[0])) {
          const product_id = parseInt(parts[0])
          const { data: res } = await axios.post(`${BASE()}/orders/create`,
            { product_id },
            { headers: jsonHdrs() }
          ).catch(e => { throw e?.response?.data?.error?.message || e?.message || 'Gagal' })
          if (!res.success) throw res.error?.message || 'Gagal membuat order'
          return await sendOrderSuccess(conn, m, res, null, 1, usedPrefix)
        }

        if (parts.length < 2) {
          return conn.reply(m.chat,
            `❌ Format salah!\n\n` +
            `Contoh:\n` +
            `• ${usedPrefix}belinokos indo,whatsapp\n` +
            `• ${usedPrefix}belinokos indonesia,wa\n` +
            `• ${usedPrefix}belinokos indo,whatsapp,1\n\n` +
            `Atau cek ID dulu:\n` +
            `• ${usedPrefix}nokosnegara\n` +
            `• ${usedPrefix}nokoslayanan`, m)
        }

        const [countryArg, platformArg, rankArg] = parts

        const [countries, services] = await Promise.all([getCountries(), getServices()])

        const country = findCountry(countries, countryArg)
        if (!country) {
          const list = countries.slice(0, 8).map(c => `• ${c.emoji || ''} ${c.name} → ID: *${c.id}* (kode: ${c.code})`).join('\n')
          return conn.reply(m.chat,
            `❌ Negara *${countryArg}* tidak ditemukan.\n\n` +
            `Contoh negara yang tersedia:\n${list}\n\n` +
            `Cek semua: *${usedPrefix}nokosnegara*`, m)
        }

        const platform = findPlatform(services, platformArg)
        if (!platform) {
          const list = services.slice(0, 8).map(s => `• ${s.name} → ID: *${s.id}* (kode: ${s.code})`).join('\n')
          return conn.reply(m.chat,
            `❌ Platform *${platformArg}* tidak ditemukan.\n\n` +
            `Contoh platform yang tersedia:\n${list}\n\n` +
            `Cek semua: *${usedPrefix}nokoslayanan*`, m)
        }

        const allProducts = await getProducts(country.id, platform.id)
        const candidates = allProducts.filter(p => p.active && p.available > 0)

        if (!candidates.length) {
          return conn.reply(m.chat,
            `❌ Tidak ada produk aktif untuk:\n` +
            `🌍 ${country.emoji || ''} ${country.name} (ID: ${country.id})\n` +
            `📱 ${platform.name} (ID: ${platform.id})\n\n` +
            `Cek produk tersedia: *${usedPrefix}nokosproduk ${country.id},${platform.id}*`, m)
        }

        // Tentukan starting rank
        let startIdx = 0
        if (rankArg && /^\d+$/.test(rankArg)) {
          const rank = parseInt(rankArg)
          const byId = candidates.findIndex(p => p.id === rank)
          startIdx = byId !== -1 ? byId : Math.max(0, Math.min(rank - 1, candidates.length - 1))
        }

        // Buat kandidat: mulai dari startIdx, lanjut ke sisa list (tidak wrap)
        const orderedCandidates = [
          ...candidates.slice(startIdx),
          ...candidates.slice(0, startIdx)
        ]

        const { res, product, attempts } = await tryOrderWithFallback(orderedCandidates)
        await sendOrderSuccess(conn, m, res, { country, platform, product, attempts }, attempts, usedPrefix)
        break
      }

      case 'nokosfinish': {
        if (!text) return conn.reply(m.chat, `❌ Masukkan ID order!\n\nContoh: *${usedPrefix}nokosfinish VTXAB3X9K2*`, m)
        await conn.reply(m.chat, global.wait, m)
        const { data: res } = await axios.post(`${BASE()}/orders/finish`,
          { id: text.trim() }, { headers: jsonHdrs() })
        if (!res.success) throw res.error?.message || 'Gagal menyelesaikan order'
        await conn.reply(m.chat,
          `╭━━━〔 🏁 ORDER SELESAI 〕━━━⬣\n│\n` +
          `│ 🆔 ID     : *${res.data.order_id}*\n` +
          `│ ✅ Status : *${res.data.status}*\n│\n` +
          `╰━━━〔 Nomor telah dilepas 〕━━⬣`, m)
        break
      }

      case 'nokosresend': {
        if (!text) return conn.reply(m.chat, `❌ Masukkan ID order!\n\nContoh: *${usedPrefix}nokosresend VTXAB3X9K2*`, m)
        await conn.reply(m.chat, global.wait, m)
        const { data: res } = await axios.post(`${BASE()}/orders/resend`,
          { id: text.trim() }, { headers: jsonHdrs() })
        if (!res.success) throw res.error?.message || 'Gagal resend OTP'
        await conn.reply(m.chat,
          `╭━━━〔 🔄 RESEND OTP 〕━━━⬣\n│\n` +
          `│ 🆔 ID     : *${res.data.order_id}*\n` +
          `│ ⏳ Status : ${res.data.status}\n` +
          `│ 📤 Resent : ${res.data.resent ? '✅ Berhasil dikirim ulang' : '❌ Platform tidak support resend'}\n│\n` +
          `╰━━━〔 VTechOTP Resend 〕━━⬣`, m)
        break
      }

      case 'nokoscancel': {
        if (!text) return conn.reply(m.chat, `❌ Masukkan ID order!\n\nContoh: *${usedPrefix}nokoscancel VTXAB3X9K2*\n\n⚠️ Cancel hanya bisa dilakukan minimal 2 menit setelah order dibuat.`, m)
        await conn.reply(m.chat, global.wait, m)
        const { data: res } = await axios.post(`${BASE()}/orders/cancel`,
          { id: text.trim() }, { headers: jsonHdrs() })
        if (!res.success) throw res.error?.message || 'Gagal cancel order'
        await conn.reply(m.chat,
          `╭━━━〔 ❌ ORDER DIBATALKAN 〕━━━⬣\n│\n` +
          `│ 🆔 ID         : *${res.data.order_id}*\n` +
          `│ ✅ Status     : *${res.data.status}*\n` +
          `│ 💸 Refund     : Rp ${res.data.refund_amount?.toLocaleString('id-ID')}\n` +
          `│ 💰 Saldo Baru : Rp ${res.data.new_balance?.toLocaleString('id-ID')}\n│\n` +
          `╰━━━〔 Saldo telah dikembalikan 〕━━⬣`, m)
        break
      }
    }
  } catch (e) {
    const msg = typeof e === 'string' ? e : (e?.response?.data?.error?.message || e?.message || String(e))
    conn.reply(m.chat, `❌ *Error:* ${msg}`, m)
  }
}

handler.help = [
  'belinokos <product_id>',
  'belinokos <negara>,<platform>',
  'belinokos <negara>,<platform>,<rank>',
  'nokosfinish <id_order>',
  'nokosresend <id_order>',
  'nokoscancel <id_order>'
]
handler.tags = ['nokos']
handler.command = /^(belinokos|nokosfinish|nokosresend|nokoscancel)$/i
handler.owner = true

module.exports = handler
