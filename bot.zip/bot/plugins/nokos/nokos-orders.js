const axios = require('axios')

const BASE = () => global.nokos_base
const TOKEN = () => global.nokos_token
const headers = () => ({ Authorization: `Bearer ${TOKEN()}` })

const statusEmoji = {
  ACTIVE: '⏳',
  OTP_RECEIVED: '✅',
  COMPLETED: '🏁',
  CANCELED: '❌',
  EXPIRED: '⌛'
}

function formatOrder(o) {
  const emoji = statusEmoji[o.status] || '❓'
  let teks = `│ *ID* : ${o.id}\n`
  teks += `│ *Status* : ${emoji} ${o.status}\n`
  if (o.phone_number) teks += `│ *Nomor* : ${o.phone_number}\n`
  if (o.otp_code) teks += `│ *OTP Code* : *${o.otp_code}*\n`
  if (o.otp_message) teks += `│ *Pesan OTP* : ${o.otp_message}\n`
  if (o.amount) teks += `│ *Harga* : Rp ${o.amount?.toLocaleString('id-ID')}\n`
  if (o.expires_at) teks += `│ *Expired* : ${new Date(o.expires_at).toLocaleString('id-ID')}\n`
  if (o.failed_reason) teks += `│ *Alasan* : ${o.failed_reason}\n`
  teks += `│\n`
  return teks
}

let handler = async (m, { conn, command, args, text, usedPrefix }) => {
  try {
    switch (command) {
      case 'nokosorders':
      case 'nokosorder': {
        await conn.reply(m.chat, global.wait, m)
        const params = { limit: args[0] || 10 }
        if (args[1]) params.status = args[1].toUpperCase()
        const { data: res } = await axios.get(`${BASE()}/orders`, { headers: headers(), params })
        if (!res.success) throw res.error?.message || 'Gagal mengambil orders'
        const list = res.data
        if (!list.length) return conn.reply(m.chat, '📭 Tidak ada order ditemukan.', m)
        let teks = `╭━━━〔 📋 DAFTAR ORDER NOKOS 〕━━━⬣\n│\n`
        for (const o of list) teks += formatOrder(o)
        teks += `╰━━━〔 Total: ${list.length} order 〕━━⬣\n\n`
        teks += `💡 Filter: *${usedPrefix}nokosorders <limit> <status>*\n`
        teks += `📌 Status: ACTIVE | OTP_RECEIVED | COMPLETED | CANCELED | EXPIRED`
        await conn.reply(m.chat, teks, m)
        break
      }

      case 'nokosaktif': {
        await conn.reply(m.chat, global.wait, m)
        const { data: res } = await axios.get(`${BASE()}/orders/active`, { headers: headers() })
        if (!res.success) throw res.error?.message || 'Gagal mengambil order aktif'
        const list = res.data
        if (!list.length) return conn.reply(m.chat, '📭 Tidak ada order aktif saat ini.', m)
        let teks = `╭━━━〔 ⏳ ORDER AKTIF NOKOS 〕━━━⬣\n│\n`
        for (const o of list) teks += formatOrder(o)
        teks += `╰━━━〔 Total: ${list.length} order aktif 〕━━⬣`
        await conn.reply(m.chat, teks, m)
        break
      }

      case 'nokoscekorder':
      case 'nokosstatus': {
        if (!text) return conn.reply(m.chat, `❌ Masukkan ID order!\n\nContoh: *${usedPrefix}nokoscekorder VTXAB3X9K2*`, m)
        await conn.reply(m.chat, global.wait, m)
        const { data: res } = await axios.get(`${BASE()}/orders/${text.trim()}`, { headers: headers() })
        if (!res.success) throw res.error?.message || 'Gagal mengambil detail order'
        const o = res.data
        let teks = `╭━━━〔 🔍 DETAIL ORDER NOKOS 〕━━━⬣\n│\n`
        teks += formatOrder(o)
        teks += `╰━━━〔 VTechOTP Order Detail 〕━━⬣`
        await conn.reply(m.chat, teks, m)
        break
      }
    }
  } catch (e) {
    const msg = e?.response?.data?.error?.message || e?.message || e
    conn.reply(m.chat, `❌ *Error:* ${msg}`, m)
  }
}

handler.help = [
  'nokosorders [limit] [status]',
  'nokosaktif',
  'nokoscekorder <id_order>'
]
handler.tags = ['nokos']
handler.command = /^(nokosorders|nokosorder|nokosaktif|nokoscekorder|nokosstatus)$/i
handler.owner = true

module.exports = handler
