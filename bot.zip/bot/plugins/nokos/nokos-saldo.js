const axios = require('axios')

const BASE = () => global.nokos_base
const TOKEN = () => global.nokos_token
const headers = () => ({ Authorization: `Bearer ${TOKEN()}` })

let handler = async (m, { conn }) => {
  try {
    await conn.reply(m.chat, global.wait, m)
    const { data: res } = await axios.get(`${BASE()}/balance`, { headers: headers() })
    if (!res.success) throw res.error?.message || 'Gagal mengambil saldo'
    const d = res.data
    let teks = `╭━━━〔 💰 SALDO NOKOS 〕━━━⬣\n│\n`
    teks += `│ Mata Uang : *${d.currency}*\n`
    teks += `│ Saldo     : *${d.currency} ${d.balance?.toLocaleString('id-ID')}*\n│\n`
    teks += `╰━━━〔 VTechOTP Balance 〕━━⬣`
    await conn.reply(m.chat, teks, m)
  } catch (e) {
    const msg = e?.response?.data?.error?.message || e?.message || e
    conn.reply(m.chat, `❌ *Error:* ${msg}`, m)
  }
}

handler.help = ['nokossaldo']
handler.tags = ['nokos']
handler.command = /^(nokossaldo|nokosbal|nokosbalance)$/i
handler.owner = true

module.exports = handler
