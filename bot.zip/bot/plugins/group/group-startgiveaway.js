let handler = async (m, { usedPrefix, text, command, participants  }) => {
    conn.giveway = conn.giveway ? conn.giveway : {}
    let id = m.chat
    let q = m.quoted ? m.quoted : m
        let mime = (q.msg || q).mimetype || q.mediaType || ''
        text = text ? text : m.quoted && m.quoted.text ? m.quoted.text : m.quoted && m.quoted.caption ? m.quoted.caption : m.quoted && m.quoted.description ? m.quoted.description : ''
        if (!text) throw `Contoh : ${usedPrefix + command} GIVEAWAY AKAUN PREMIUM`
    if (id in conn.giveway) {
        throw `_*Masih ada GIVEAWAY dalam sembang ini!*_`
    }
    let capt = `Berjaya memulakan giveaway!\n\n*${usedPrefix}ikut* - untuk sertai giveaway\n*${usedPrefix}cekgiveaway* - untuk semak peserta\n*${usedPrefix}rollgiveaway* - untuk cari pemenang\n*${usedPrefix}deletegiveaway* - untuk padam giveaway\n\n*MAKLUMAT:*\n\n${text}`
    conn.giveway[id] = [
        conn.sendMessage(m.chat, { text: capt, mentions: participants.map(a => a.id) }),
                [],
        text
    ]
}
handler.help = ['mulaigiveaway'].map(v => v + ' <teks>')
handler.tags = ['group']
handler.command = /^(start|mulai)giveaway$/i
handler.group = true
handler.admin = true
module.exports = handler
