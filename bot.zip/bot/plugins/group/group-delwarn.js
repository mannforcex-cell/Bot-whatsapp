let handler = async (m, { conn, args, groupMetadata}) => {
        let who
        if (m.isGroup) who = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : false
        else who = m.chat
        if (!who) throw `✳️ Tag atau sebut seseorang`
        if (!(who in global.db.data.users)) throw `✳️ Pengguna tidak dijumpai dalam pangkalan data`
       let warn = global.db.data.users[who].warn
       if (warn > 0) {
         global.db.data.users[who].warn -= 1
         m.reply(`⚠️ *AMARAN*

▢ Amaran: *-1*
▢ Jumlah Amaran: *${warn - 1}*`)
         m.reply(`✳️ Seorang admin telah mengurangkan amalannya, kini awak mempunyai *${warn - 1}*`, who)
         } else if (warn == 0) {
            m.reply('✳️ Pengguna tiada amaran')
        }

}
handler.help = ['delwarn @user']
handler.tags = ['group']
handler.command = ['delwarn', 'unwarn']
handler.group = true
handler.admin = true
handler.botAdmin = true

module.exports = handler
