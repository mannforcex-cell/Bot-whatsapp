let handler = async (m, { usedPrefix }) => {
    let id = m.chat
    conn.giveway = conn.giveway ? conn.giveway : {}
    if (!(id in conn.giveway)) throw `_*Tiada GIVEAWAY berlangsung dalam kumpulan ini!*_\n\n*${usedPrefix}mulaigiveaway* - untuk memulakan giveaway`

    let absen = conn.giveway[id][1]
    const wasVote = absen.includes(m.sender)
    if (wasVote) throw '*Awak sudah menyertai!*'
    absen.push(m.sender)
    m.reply(`*Done!*\n\n\`\`\`Jumlah yang telah menyertai GIVEAWAY\`\`\`\n*${absen.length} Ahli*`)
    let d = new Date
    let date = d.toLocaleDateString('ms-MY', {
        day: 'numeric',
        month: 'long',
        year: 'numeric'
    })
    let list = absen.map((v, i) => `│ ${i + 1}. @${v.split`@`[0]}`).join('\n')
}
handler.help = ['ikutgiveaway']
handler.tags = ['group']
handler.command = /^(ikut|ikutgiveaway)$/i
handler.group = true
module.exports = handler
