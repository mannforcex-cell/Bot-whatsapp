let handler = async (m, { conn, args, isAdmin, isOwner }) => {
    if (!m.isGroup) return m.reply("Ciri ini hanya boleh digunakan dalam kumpulan.")
    if (!(isAdmin || isOwner)) return m.reply("Maaf, ciri ini hanya boleh digunakan oleh admin kumpulan.")

    global.db.data.chats = global.db.data.chats || {}

    if (!global.db.data.chats[m.chat]) {
        global.db.data.chats[m.chat] = {}
    }

    if (!args[0]) return m.reply("Sila guna: .antitagsw *on/off*")

    if (args[0] === "on") {
        if (global.db.data.chats[m.chat].antitagsw) return m.reply("Ciri Anti Tag Status WhatsApp sudah aktif dalam kumpulan ini.")
        global.db.data.chats[m.chat].antitagsw = true
        return m.reply("*Anti Tag Status WhatsApp* berjaya diaktifkan dalam kumpulan ini.")
    } else if (args[0] === "off") {
        if (!global.db.data.chats[m.chat].antitagsw) return m.reply("Ciri Anti Tag Status WhatsApp sudah tidak aktif dalam kumpulan ini.")
        global.db.data.chats[m.chat].antitagsw = false
        return m.reply("*Anti Tag Status WhatsApp* berjaya dinonaktifkan dalam kumpulan ini.")
    } else {
        return m.reply("Sila pilih pilihan yang sah: *on/off*")
    }
}

handler.before = async (m, { conn, isBotAdmin, isAdmin }) => {
    global.db.data.chats = global.db.data.chats || {}
    if (!global.db.data.chats[m.chat]) {
        global.db.data.chats[m.chat] = {}
    }

    if (!m.isGroup || !global.db.data.chats[m.chat].antitagsw) return

    const isTaggingInStatus = (
        m.mtype === 'groupStatusMentionMessage' ||
        (m.quoted && m.quoted.mtype === 'groupStatusMentionMessage') ||
        (m.message && m.message.groupStatusMentionMessage) ||
        (m.message && m.message.protocolMessage && m.message.protocolMessage.type === 25)
    )

    if (!isTaggingInStatus) return

    await conn.sendMessage(m.chat, { delete: m.key })

    if (isAdmin) {
        let warningMessage = `Kumpulan ini dikesan ditag dalam Status WhatsApp\n\n` +
                            `@${m.sender.split("@")[0]}, sila jangan tag kumpulan dalam status WhatsApp` +
                            `\n\nPerkara ini tidak dibenarkan dalam kumpulan ini.`

        return conn.sendMessage(m.chat, { text: warningMessage, mentions: [m.sender] })
    }

    if (isBotAdmin) {
        await conn.groupParticipantsUpdate(m.chat, [m.sender], "remove")
        await conn.sendMessage(m.chat, { text: `@${m.sender.split("@")[0]} telah dikeluarkan dari kumpulan kerana mentag kumpulan dalam status WhatsApp.`, mentions: [m.sender] })
    } else {
        let warningMessage = `Kumpulan ini dikesan ditag dalam Status WhatsApp\n\n` +
                            `@${m.sender.split("@")[0]}, sila jangan tag kumpulan dalam status WhatsApp` +
                            `\n\nPerkara ini tidak dibenarkan dalam kumpulan ini.`

        return conn.sendMessage(m.chat, { text: warningMessage, mentions: [m.sender] })
    }
}

handler.command = ['antitagsw']
handler.help = ['antitagsw'].map(a => a + ' *on/off*');
handler.tags = ['group']
handler.group = true
handler.admin = true

module.exports = handler
