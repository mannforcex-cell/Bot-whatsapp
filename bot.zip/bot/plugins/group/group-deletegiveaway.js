let handler = async (m, { conn, participants, usedPrefix }) => {
    let id = m.chat
    conn.giveway = conn.giveway ? conn.giveway : {}
    if (!(id in conn.giveway)) throw `_*Tiada GIVEAWAY berlangsung dalam kumpulan ini!*_\n\n*${usedPrefix}mulaigiveaway* - untuk memulakan giveaway`
    delete conn.giveway[id]
    conn.sendMessage(m.chat, { text: '*GIVEAWAY* telah tamat', mentions: participants.map(a => a.id) })
}
handler.help = ['hapusgiveaway']
handler.tags = ['group']
handler.command = /^(delete|hapus)giveaway$/i
handler.group = true
handler.admin = true
module.exports = handler
