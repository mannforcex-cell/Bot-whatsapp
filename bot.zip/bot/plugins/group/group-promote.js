let handler = async (m, { teks, conn, isOwner, isAdmin, args, command }) => {
    if (m.isBaileys) return;

    if (!(isAdmin || isOwner)) {
        global.dfail('admin', m, conn);
        throw false;
    }

    let ownerGroup = m.chat.split`-`[0] + "@s.whatsapp.net";
    let users = [];

    if (m.quoted) {
        if (m.quoted.sender === ownerGroup || m.quoted.sender === conn.user.jid) return;
        users = [m.quoted.sender];
    } else if (m.mentionedJid && m.mentionedJid.length > 0) {
        users = m.mentionedJid;
    } else {
        throw 'Tag siapa yang nak dinaikkan jawatan?';
    }

    users = users.filter(u => !(u == ownerGroup || u.includes(conn.user.jid)));

    if (users.length === 0) return m.reply('Tiada pengguna yang sah untuk dipromosikan!');

    for (let user of users) {
        if (user.endsWith("@s.whatsapp.net")) {
            try {
                await conn.groupParticipantsUpdate(m.chat, [user], "promote");
                await m.reply(`Berjaya ${command} @${user.split('@')[0]}!`, m.chat, {
                    mentions: [user]
                });
            } catch (e) {
                console.error(e);
                await m.reply(`Gagal ${command} @${user.split('@')[0]}!`, m.chat, {
                    mentions: [user]
                });
            }
        }
    }
};

handler.help = ['promote @user'];
handler.tags = ['group', 'owner'];
handler.command = /^(promo?te|admin|\^)$/i;
handler.group = true;
handler.botAdmin = true;
handler.admin = true;
handler.fail = null;

module.exports = handler;
