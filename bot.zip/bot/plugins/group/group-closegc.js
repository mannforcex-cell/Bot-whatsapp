let moment = require('moment-timezone');

const timeZone = 'Asia/Kuala_Lumpur';

let handler = async (m, { conn, command, args, isOwner, isAdmin, usedPrefix }) => {
    let chat = global.db.data.chats[m.chat];
    if (!m.isGroup) throw 'Arahan ini hanya boleh digunakan dalam kumpulan!';
    if (!(isAdmin || isOwner)) throw 'Arahan ini hanya boleh digunakan oleh admin kumpulan!';

    if (command === 'aktif' && args[0] === 'closegc') {
        if (args.length < 2) throw `Format salah! Guna *${usedPrefix + command} jam tutup|jam buka*\nContoh: ${usedPrefix + command} 21|5`;
        let [closeTime, openTime] = args[1].split('|').map(Number);
        if (isNaN(closeTime) || isNaN(openTime)) throw 'Jam tutup dan buka mesti nombor!';
        chat.autoGc = { closeTime, openTime };
        m.reply(`Auto kumpulan tutup/buka diaktifkan. Kumpulan akan tutup pukul ${closeTime}:00 dan buka pukul ${openTime}:00.`);
    } else if (command === 'mati' && args[0] === 'closegc') {
        delete chat.autoGc;
        m.reply('Auto kumpulan tutup/buka dinonaktifkan.');
    }
};

handler.command = /^(aktif|mati)$/i;
handler.help = ['aktif closegc jam tutup|jam buka', 'mati closegc'];
handler.tags = ['group'];
handler.admin = true;
handler.group = true;

module.exports = handler;


const checkGroupsStatus = async (conn) => {
    const currentHour = moment().tz(timeZone).hour();

    for (const chatId of Object.keys(global.db.data.chats)) {
        const chat = global.db.data.chats[chatId];
        if (!chat.autoGc) continue;

        const { closeTime, openTime } = chat.autoGc;

        if (currentHour === closeTime && chat.groupStatus !== 'closed') {
            try {
                await conn.groupSettingUpdate(chatId, 'announcement');
                await conn.sendMessage(chatId, { text: `( AUTOMATIK ) 𝗞𝗨𝗠𝗣𝗨𝗟𝗔𝗡 𝗧𝗨𝗧𝗨𝗣, 𝗔𝗞𝗔𝗡 𝗗𝗜𝗕𝗨𝗞𝗔 𝗣𝗨𝗞𝗨𝗟 ${openTime}:00 𝗠𝗬𝗧` });
                chat.groupStatus = 'closed';
            } catch (error) {
                console.error(`Error closing group ${chatId}:`, error);
            }
        }

        if (currentHour === openTime && chat.groupStatus !== 'opened') {
            try {
                await conn.groupSettingUpdate(chatId, 'not_announcement');
                await conn.sendMessage(chatId, { text: `( AUTOMATIK ) 𝗞𝗨𝗠𝗣𝗨𝗟𝗔𝗡 𝗕𝗨𝗞𝗔, 𝗔𝗞𝗔𝗡 𝗗𝗜𝗧𝗨𝗧𝗨𝗣 𝗣𝗨𝗞𝗨𝗟 ${closeTime}:00 𝗠𝗬𝗧` });
                chat.groupStatus = 'opened';
            } catch (error) {
                console.error(`Error opening group ${chatId}:`, error);
            }
        }
    }
};

const interval = 60000;
setInterval(() => {
    checkGroupsStatus(conn);
}, interval);
