let handler = async (m, { isAdmin, isOwner, isBotAdmin, conn, args, usedPrefix, command }) => {
    if (!(isAdmin || isOwner)) {
        global.dfail('admin', m, conn)
        throw false
    }
    if (!isBotAdmin) {
        global.dfail('botAdmin', m, conn)
        throw false
    }
    let prefix = usedPrefix
    let bu = `Kumpulan telah *dibuka* oleh @${m.sender.split`@`[0]} dan kini semua ahli boleh menghantar mesej.
Taip *${usedPrefix}group buka*
Untuk membuka kumpulan!`.trim()

    let isClose = {
        'open': 'not_announcement',
        'buka': 'not_announcement',
        'on': 'not_announcement',
        '1': 'not_announcement',
        'close': 'announcement',
        'tutup': 'announcement',
        'off': 'announcement',
        '0': 'announcement',
    }[(args[0] || '')]

    if (isClose === undefined) {
        var text5 = `Contoh:
${usedPrefix + command} tutup
${usedPrefix + command} buka`
        m.reply(text5)
        throw false
    } else if (isClose === 'announcement') {
        await conn.groupSettingUpdate(m.chat, isClose)
        let teks = `Kumpulan telah *ditutup* oleh @${m.sender.split`@`[0]} dan kini hanya admin yang boleh menghantar mesej.
Taip *${usedPrefix}group buka*
Untuk membuka kumpulan!`.trim()
        await m.reply(teks)
    } else if (isClose === 'not_announcement') {
        await conn.groupSettingUpdate(m.chat, isClose)
        await m.reply(bu)
    }
}

handler.help = ['grup <open/close>']
handler.tags = ['group']
handler.command = /^(g(ro?up|c?)?)$/i
handler.group = true
handler.botAdmin = false

module.exports = handler
