let handler = async (m, { conn, usedPrefix }) => {
    let id = m.chat
    conn.giveway = conn.giveway ? conn.giveway : {}
    if (!(id in conn.giveway)) throw `_*Tiada GIVEAWAY berlangsung dalam kumpulan ini!*_\n\n*${usedPrefix}mulaigiveaway* - untuk memulakan giveaway`

    let d = new Date
    let date = d.toLocaleDateString('ms-MY', {
        day: 'numeric',
        month: 'long',
        year: 'numeric'
    })
    let absen = conn.giveway[id][1]
    let cita = absen[Math.floor(Math.random() * absen.length)]
    let tag = `@${cita.split`@`[0]}`
    let loadd = [
 '■□ 10%',
 '□■ 20%',
 '■□ 30%',
 '□■ 40%',
 '■□ 50%',
 '□■ 60%',
 '■□ 70%',
 '□■ 80%',
 '■□ 90%',
 '*Mencari Pemenang...*'
 ]

let { key } = await conn.sendMessage(m.chat, {text: '*Sedang Mencari Pemenang*'})

for (let i = 0; i < loadd.length; i++) {
await sleep(1000)
await conn.sendMessage(m.chat, {text: loadd[i], edit: key })} return conn.reply(m.chat, `🎊 *TAHNIAH* 🎉
${tag} Awak adalah Pemenang Giveaway!🎉

Tarikh: ${date}
————————————————————————
_*Nota:* Padam giveaway selepas selesai dengan menaip *.hapusgiveaway*_`, m, { contextInfo: { mentionedJid: absen } })
}
handler.help = ['rollgiveaway']
handler.tags = ['group']
handler.command = /^(rolling|rollgiveaway|rollinggiveaway)$/i
handler.admin = true
module.exports = handler

const sleep = (ms) => {
return new Promise(resolve => setTimeout(resolve, ms));
}
