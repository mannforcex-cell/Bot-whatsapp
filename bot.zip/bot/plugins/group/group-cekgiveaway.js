let handler = async (m, { conn, usedPrefix }) => {
    let id = m.chat
    conn.giveway = conn.giveway ? conn.giveway : {}
    if (!(id in conn.giveway)) throw `_*Tiada *GIVEAWAY berlangsung dalam kumpulan ini!*_\n\n*${usedPrefix}mulaigiveaway* - untuk memulakan giveaway`

    let d = new Date
    let date = d.toLocaleDateString('ms-MY', {
        day: 'numeric',
        month: 'long',
        year: 'numeric'
    })
    let absen = conn.giveway[id][1]
    let list = absen.map((v, i) => `│ ${i + 1}. @${v.split`@`[0]}`).join('\n')
    conn.reply(m.chat, `*「 SENARAI PESERTA 」*

Tarikh: ${date}
${conn.giveway[id][2]}

┌ *Yang sudah menyertai:*
│ 
│ Jumlah: ${absen.length}
${list}
│ 
└────

_${global.wm}_`, m, { contextInfo: { mentionedJid: absen } })
}
handler.help = ['cekgiveaway']
handler.tags = ['group']
handler.command = /^cekgiveaway$/i
handler.admin = true
module.exports = handler
