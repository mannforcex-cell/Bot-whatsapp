let handler = async (m, { conn, usedPrefix }) => {
    let id = m.chat
    conn.absen = conn.absen ? conn.absen : {}
    if (!(id in conn.absen)) throw `_*Maaf, Tiada kehadiran hari ini!*_\n\n*${usedPrefix}mulaiabsen* - untuk memulakan kehadiran`

    let absen = conn.absen[id][1]
    const wasVote = absen.includes(m.sender)
    if (wasVote) throw '*Awak sudah tandatangan hadir！🙄*'
    absen.push(m.sender)
    m.reply(`Done!`)
    let d = new Date
    let date = d.toLocaleDateString('ms-MY', {
        day: 'numeric',
        month: 'long',
        year: 'numeric'
    })
    let list = absen.map((v, i) => `├ ${i + 1}. @${v.split`@`[0]}`).join('\n')
    let caption = `
Tarikh: ${date}
${conn.absen[id][2]}
┌「 *Kehadiran* 」  
├ Jumlah: ${absen.length}
${list} 
└────
_Sila Taip ${usedPrefix}absen Untuk Hadir_
_Taip ${usedPrefix}cekabsen Untuk Semak Kehadiran_`.trim()
    await conn.reply(m.chat, caption, m, { contextInfo: { mentionedJid: absen } })
}
handler.help = ['absen']
handler.tags = ['group']
handler.command = /^(absen|hadir)$/i
handler.group = true

module.exports = handler;
