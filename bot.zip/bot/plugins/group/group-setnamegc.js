let handler = async (m, { conn, args, usedPrefix, command }) => {
    if (!args.length) {
        return m.reply(`Mana nama kumpulannya? Contoh: *${usedPrefix + command}* Nama Kumpulan Baru`);
    }

    try {
        await conn.groupUpdateSubject(m.chat, args.join(" "));
        m.reply('Berjaya menukar nama kumpulan!');
    } catch (err) {
        m.reply('Gagal menukar nama kumpulan. Pastikan bot mempunyai kebenaran Admin.');
        console.error(err);
    }
};

handler.help = ['setnamegc'];
handler.tags = ['group'];
handler.command = /^setnamegc$/i;
handler.owner = false;
handler.mods = false;
handler.premium = false;
handler.group = true;
handler.private = false;
handler.register = false;
handler.admin = true;
handler.botAdmin = true;

module.exports = handler;
