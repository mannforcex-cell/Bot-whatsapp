const axios = require('axios');
const { setInterval } = require('timers');

let lastGempaData = null;

async function getGempaInfo() {
    try {
        const url = `https://api.vtech.biz.id/api/search/gempa?apikey=${vtech}`;
        const response = await axios.get(url);
        const res = response.data.result.result;

        if (!res) {
            console.log('Data gempa tidak tersedia');
            return;
        }

        if (lastGempaData && lastGempaData.waktu === res.waktu) {
            console.log('Data gempa belum berubah, tiada peringatan.');
            return;
        }

        lastGempaData = res;

        const gempaInfo = {
            waktu: res.waktu,
            lintang: res.Lintang,
            bujur: res.Bujur,
            magnitude: res.Magnitudo,
            kedalaman: res.Kedalaman,
            wilayah: res.Wilayah,
            potensi: res.Potensi,
            gambar: res.image
        };

        console.log(`
        Masa Gempa: ${gempaInfo.waktu}
        Magnitud: ${gempaInfo.magnitude}
        Kawasan: ${gempaInfo.wilayah}
        Potensi: ${gempaInfo.potensi}
        Gambar: ${gempaInfo.gambar}
        `);

        sendGempaReminderToGroups(gempaInfo);
    } catch (error) {
        // API tidak tersedia atau kunci tidak sah, skip silently
    }
}

async function sendGempaReminderToGroups(gempaInfo) {
    for (const chatId of Object.keys(global.db.data.chats)) {
        const chat = global.db.data.chats[chatId];
        if (chat.notifgempa) {
            const reminderMessage = `🚨 *PERINGATAN GEMPA BUMI* 🚨\n\n🕒 Masa: ${gempaInfo.waktu}\n🌍 Kawasan: ${gempaInfo.wilayah}\n💥 Magnitud: ${gempaInfo.magnitude}\n🌐 Lintang: ${gempaInfo.lintang}\n🌐 Bujur: ${gempaInfo.bujur}\n🔍 Kedalaman: ${gempaInfo.kedalaman}\n🌊 Potensi: ${gempaInfo.potensi}\n📷 Gambar Peta: ${gempaInfo.gambar}\n\nJaga keselamatan anda!`;
            await sendReminderToGroup(chatId, reminderMessage);
        }
    }
}

async function sendReminderToGroup(chatId, text) {
    await conn.sendMessage(chatId, { text });
}

function startGempaReminder() {
    setInterval(() => {
        console.log('Menyemak data gempa terkini...');
        getGempaInfo();
    }, 60 * 60 * 1000);
}

startGempaReminder();
