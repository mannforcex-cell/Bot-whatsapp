let handler = async (m, { conn, usedPrefix, text }) => {
    conn.absen = conn.absen ? conn.absen : {}
    let id = m.chat
    if (id in conn.absen) {
        throw `_*Masih ada kehadiran di sembang ini!*_\n\n*${usedPrefix}hapusabsen* - untuk memadamkan kehadiran`
    }
    conn.absen[id] = [
        m.reply(`Berjaya memulakan kehadiran!\n\n*${usedPrefix}absen* - untuk tandatangan hadir\n*${usedPrefix}cekabsen* - untuk semak kehadiran\n*${usedPrefix}hapusabsen* - untuk padam data kehadiran`),
        [],
        text
    ]
}
handler.help = ['mulaiabsen [teks]']
handler.tags = ['group']
handler.command = /^(start|mulai)absen$/i
handler.group = true
handler.admin = true
module.exports = handler;
