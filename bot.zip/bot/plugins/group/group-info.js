let handler = async (m, { conn, participants, groupMetadata, text }) => {
    const getGroupAdmins = (participants) => {
        let admins = []
        for (let i of participants) {
            if (i.admin) admins.push(i.jid || i.id)
        }
        return admins
    }

    let pp = 'https://a.top4top.io/p_37802zcmd1.png'
    try { pp = await conn.profilePictureUrl(m.chat, 'image') } catch (e) {}

    let { isBanned, welcome, detect, sWelcome, sBye, sPromote, sDemote, antiLink, expired } = global.db.data.chats[m.chat]
    let antidelete = !global.db.data.chats[m.chat].delete

    const groupAdmins = getGroupAdmins(participants)
    let listAdmin = groupAdmins.map((v, i) => `  ${i + 1}. @${(v || '').split('@')[0]}`).join('\n')

    if (text) return m.reply(msToDate(expired - new Date() * 1))

    let caption =
`*ᴍᴀᴋʟᴜᴍᴀᴛ ᴋᴜᴍᴘᴜʟᴀɴ* — ᴠʏɴᴀᴀᴍᴅ

ɪᴅ: ${groupMetadata.id}
ɴᴀᴍᴀ: ${groupMetadata.subject}
ᴀʜʟɪ: ${participants.length}
ᴘᴇɴᴄɪᴘᴛᴀ: @${m.chat.split('-')[0]}

*ᴋᴇᴛᴇʀᴀɴɢᴀɴ*
${groupMetadata.desc || '—'}

*ᴀᴅᴍɪɴ*
${listAdmin || '  —'}

*ᴛᴇᴛᴀᴘᴀɴ ʙᴏᴛ*
  ᴀɴᴛɪ ᴘᴀᴜᴛᴀɴ   ${antiLink ? 'ʜɪᴅᴜᴘ' : 'ᴍᴀᴛɪ'}
  ᴀɴᴛɪ ᴘᴀᴅᴀᴍ    ${antidelete ? 'ʜɪᴅᴜᴘ' : 'ᴍᴀᴛɪ'}
  ᴅɪsᴇᴋᴀᴛ        ${isBanned ? 'ʏᴀ' : 'ᴛɪᴅᴀᴋ'}
  ᴋᴇsᴀɴ          ${detect ? 'ʜɪᴅᴜᴘ' : 'ᴍᴀᴛɪ'}
  ᴀʟᴜᴀɴ          ${welcome ? 'ʜɪᴅᴜᴘ' : 'ᴍᴀᴛɪ'}

*ᴍᴇsᴇᴊ ᴛᴇʀsᴜɴ*
  ᴀʟᴜᴀɴ    ${sWelcome ? 'ᴅɪᴛᴇᴛᴀᴘ' : 'ᴛᴇʀsᴜɴ'}
  ᴛɪɴɢɢᴀʟ  ${sBye ? 'ᴅɪᴛᴇᴛᴀᴘ' : 'ᴛᴇʀsᴜɴ'}
  ɴᴀɪᴋ     ${sPromote ? 'ᴅɪᴛᴇᴛᴀᴘ' : 'ᴛᴇʀsᴜɴ'}
  ᴛᴜʀᴜɴ    ${sDemote ? 'ᴅɪᴛᴇᴛᴀᴘ' : 'ᴛᴇʀsᴜɴ'}

> © ᴠʏɴᴀᴀᴍᴅ`.trim()

    let mentionedJid = groupAdmins.concat([`${m.chat.split('-')[0]}@s.whatsapp.net`]).filter(Boolean)
    conn.sendFile(m.key.remoteJid, pp, 'kumpulan.jpg', caption, m, false, { contextInfo: { mentionedJid } })
}

handler.help = ['infogrup']
handler.tags = ['group']
handler.command = /^(gro?upinfo|info(gro?up|gc))$/i
handler.group = true

module.exports = handler

function msToDate(ms) {
    let days = Math.floor(ms / (24 * 60 * 60 * 1000))
    let daysms = ms % (24 * 60 * 60 * 1000)
    let hours = Math.floor(daysms / (60 * 60 * 1000))
    let hoursms = ms % (60 * 60 * 1000)
    let minutes = Math.floor(hoursms / (60 * 1000))
    return `${days} ʜᴀʀɪ ${hours} ᴊᴀᴍ ${minutes} ᴍɪɴɪᴛ`
}
