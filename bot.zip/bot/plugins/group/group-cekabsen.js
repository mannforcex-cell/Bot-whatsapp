let handler = async (m, { conn, usedPrefix }) => {
    let id = m.chat
    conn.absen = conn.absen ? conn.absen : {}
    if (!(id in conn.absen)) throw `_*Tiada kehadiran berlangsung dalam kumpulan ini!*_\n\n*${usedPrefix}mulaiabsen* - untuk memulakan kehadiran`

    let d = new Date
    let date = d.toLocaleDateString('ms-MY', {
        day: 'numeric',
        month: 'long',
        year: 'numeric'
    })
    let absen = conn.absen[id][1]
    let list = absen.map((v, i) => `│ ${i + 1}. @${v.split`@`[0]}`).join('\n')
    conn.reply(m.chat, `*「 KEHADIRAN 」*

Tarikh: ${date}
${conn.absen[id][2]}

┌ *Yang sudah hadir:*
│ 
│ Jumlah: ${absen.length}
${list}
│ 
└────

_${global.wm}_`, m, { contextInfo: { mentionedJid: absen } })
}
handler.help = ['cekabsen']
handler.tags = ['group']
handler.command = /^cekabsen$/i
handler.group = true

module.exports = handler;
