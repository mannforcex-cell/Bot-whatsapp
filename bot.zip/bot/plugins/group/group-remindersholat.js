let axios = require('axios');
let moment = require('moment-timezone');

const timeZone = 'Asia/Kuala_Lumpur';

async function getPrayerTimesAndSetReminders() {
    try {
        let city = 'kuala_lumpur';
        let url = `https://api.vtech.biz.id/api/tools/jadwalshalat?kota=${city}&apikey=${vtech}`;
        let response = await axios.get(url);

        let data = response.data;
        if (!data || data.result.code !== 200) {
            console.log(`[❗] Jadual solat untuk ${city.toUpperCase()} tidak dijumpai atau tidak tersedia.`);
            return;
        }
        const prayerTimes = getPrayerTimes(data);

        if (prayerTimes) {
            let jadwal = prayerTimes.timings;
            console.log(`
┌「 ${city.toUpperCase()} 」  
├ Subuh: ${jadwal.Fajr}
├ Zohor: ${jadwal.Dhuhr}
├ Asar: ${jadwal.Asr}
├ Maghrib: ${jadwal.Maghrib}
├ Isyak: ${jadwal.Isha}
└──────────`);

            setPrayerTimers(jadwal);
        } else {
            console.log(`[❗] Tiada data jadual solat untuk tarikh hari ini.`);
        }

    } catch (error) {
        // API tidak tersedia atau kunci tidak sah, skip secara senyap
    }
}

function getPrayerTimes(jsonData) {
    const today = new Date();
    const year = today.getFullYear();
    const month = String(today.getMonth() + 1).padStart(2, '0');
    const day = String(today.getDate()).padStart(2, '0');

    const todayString = `${day}-${month}-${year}`;

    for (const item of jsonData.result.data) {
        if (item.date.gregorian.date === todayString) {
            return item;
        }
    }
    return null;
}

function setPrayerTimers(jadwal) {
    let now = new Date();

    function calculateTimeDifference(prayerTime) {
        let cleanTime = prayerTime.replace(' (MYT)', '');
        let [hours, minutes] = cleanTime.split(':').map(Number);
        let prayerDate = new Date(now.getFullYear(), now.getMonth(), now.getDate(), hours, minutes);
        return prayerDate.getTime() - now.getTime();
    }

    let prayerTimes = [
        { name: 'Subuh', time: jadwal.Fajr },
        { name: 'Zohor', time: jadwal.Dhuhr },
        { name: 'Asar', time: jadwal.Asr },
        { name: 'Maghrib', time: jadwal.Maghrib },
        { name: 'Isyak', time: jadwal.Isha },
    ];

    for (let prayer of prayerTimes) {
        let timeDifference = calculateTimeDifference(prayer.time);

        if (timeDifference > 0) {
            setTimeout(() => {
                sendPrayerReminderToGroups(prayer.name, prayer.time);
            }, timeDifference);
        }
    }
}

async function sendPrayerReminderToGroups(prayerName, prayerTime) {
    for (const chatId of Object.keys(global.db.data.chats)) {
        const chat = global.db.data.chats[chatId];
        if (chat.notifsholat) {
            const reminderMessage = `⏰ *PERINGATAN SOLAT*\n\n🚨 Waktu Solat ${prayerName} telah tiba!\nJam: ${prayerTime}\nJangan lupa untuk menunaikan solat.`;
            await sendReminderToGroup(chatId, reminderMessage);
        }
    }
}

async function sendReminderToGroup(chatId, text) {
    await conn.sendMessage(chatId, { text });
}

function startDailyPrayerReminder() {
    getPrayerTimesAndSetReminders();

    setInterval(() => {
        let now = new Date();
        console.log(`Mendapat jadual solat untuk hari ini (${now.toLocaleDateString()})`);
        getPrayerTimesAndSetReminders();
    }, 6 * 60 * 60 * 1000);
}

startDailyPrayerReminder();
