let war = global.maxwarn
let handler = async (m, { conn, text, args, groupMetadata, usedPrefix, command }) => {
        let who
        if (m.isGroup) who = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : false
        else who = m.chat
        if (!who) throw `✳️ Tag atau sebut seseorang\n\n📌 Contoh : ${usedPrefix + command} @user`
        if (!(who in global.db.data.users)) throw `✳️ Pengguna tidak dijumpai dalam pangkalan data`
        let name = conn.getName(m.sender)
        let warn = global.db.data.users[who].warn
        if (warn < war) {
            global.db.data.users[who].warn += 1
            m.reply(`
⚠️ *Pengguna Diperingatkan* ⚠️

▢ *Admin:* ${name}
▢ *Pengguna:* @${who.split`@`[0]}
▢ *Amaran:* ${warn + 1}/${war}
▢ *Sebab:* ${text}`, null, { mentions: [who] })
            m.reply(`
⚠️ *AMARAN* ⚠️
Awak menerima amaran daripada admin

▢ *Amaran:* ${warn + 1}/${war} 
Jika awak menerima *${war}* amaran, awak akan dikeluarkan secara automatik dari kumpulan`, who)
        } else if (warn == war) {
            global.db.data.users[who].warn = 0
            m.reply(`⛔ Pengguna melebihi amaran *${war}*, oleh itu akan dikeluarkan`)
            await time(3000)
            await conn.groupParticipantsUpdate(m.chat, [who], 'remove')
            m.reply(`♻️ Awak dikeluarkan dari kumpulan *${groupMetadata.subject}* kerana telah diperingatkan *${war}* kali`, who)
        }
}
handler.help = ['warn @user']
handler.tags = ['group']
handler.command = ['warn']
handler.group = true
handler.admin = true
handler.botAdmin = true

module.exports = handler

const time = async (ms) => {
            return new Promise(resolve => setTimeout(resolve, ms));
        }
