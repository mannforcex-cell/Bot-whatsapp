let handler = async (m, { conn, text, usedPrefix, command, isAdmin, isOwner }) => {
  if (!(isAdmin || isOwner)) {
    global.dfail('admin', m, conn)
    throw false
  }

  let chat = global.db.data.chats[m.chat]

  if (command === 'setwelcome') {
    if (!text) {
      return m.reply(`*sᴇᴛ ᴡᴇʟᴄᴏᴍᴇ* — ᴠʏɴᴀᴀᴍᴅ

ɢᴜɴᴀ: *${usedPrefix}setwelcome <ᴍᴇsᴇᴊ>*

ᴘᴇᴍʙᴏʟᴇʜᴜʙᴀʜ:
  @user → ᴍᴇɴsʏᴇʙᴜᴛ ᴀʜʟɪ ʙᴀʜᴀʀᴜ
  @subject → ɴᴀᴍᴀ ᴋᴜᴍᴘᴜʟᴀɴ
  @desc → ᴋᴇᴛᴇʀᴀɴɢᴀɴ ᴋᴜᴍᴘᴜʟᴀɴ

> ᴡᴇʟᴄᴏᴍᴇ sᴇᴍᴀsᴀ: ${chat.sWelcome || '_(ᴛᴇʀsᴜɴ)_'}`)
    }
    chat.sWelcome = text
    m.reply(`ᴡᴇʟᴄᴏᴍᴇ ʙᴇʀᴊᴀʏᴀ ᴅɪᴛᴇᴛᴀᴘᴋᴀɴ.\n\n> ᴀᴋᴛɪꜰᴋᴀɴ: *${usedPrefix}enable welcome*`)

  } else if (command === 'setbye') {
    if (!text) {
      return m.reply(`*sᴇᴛ ʙʏᴇ* — ᴠʏɴᴀᴀᴍᴅ

ɢᴜɴᴀ: *${usedPrefix}setbye <ᴍᴇsᴇᴊ>*

ᴘᴇᴍʙᴏʟᴇʜᴜʙᴀʜ:
  @user → ᴍᴇɴsʏᴇʙᴜᴛ ᴀʜʟɪ ᴋᴇʟᴜᴀʀ
  @subject → ɴᴀᴍᴀ ᴋᴜᴍᴘᴜʟᴀɴ

> ʙʏᴇ sᴇᴍᴀsᴀ: ${chat.sBye || '_(ᴛᴇʀsᴜɴ)_'}`)
    }
    chat.sBye = text
    m.reply(`ʙʏᴇ ʙᴇʀᴊᴀʏᴀ ᴅɪᴛᴇᴛᴀᴘᴋᴀɴ.\n\n> ᴀᴋᴛɪꜰᴋᴀɴ: *${usedPrefix}enable welcome*`)

  } else if (command === 'resetwelcome') {
    chat.sWelcome = ''
    m.reply('ᴡᴇʟᴄᴏᴍᴇ ᴅɪᴛᴇᴛᴀᴘsᴇᴍᴜʟᴀ ᴋᴇ ᴛᴇʀsᴜɴ.')

  } else if (command === 'resetbye') {
    chat.sBye = ''
    m.reply('ʙʏᴇ ᴅɪᴛᴇᴛᴀᴘsᴇᴍᴜʟᴀ ᴋᴇ ᴛᴇʀsᴜɴ.')
  }
}

handler.help = ['setwelcome <mesej>', 'setbye <mesej>', 'resetwelcome', 'resetbye']
handler.tags = ['group']
handler.command = /^(setwelcome|setbye|resetwelcome|resetbye)$/i
handler.group = true

module.exports = handler
