const moment = require('moment-timezone');

let handler = async (m, { text, conn, usedPrefix, command }) => {
    try {
        if (!text) {
            return m.reply(`╭═══❯ *PENJELAJAH MIMPI* ❮═══
│
│ 🌙 Teroka Dunia Mimpimu!
│ 
│ 📝 *Format:*
│ ${usedPrefix}${command} [nama/kata kunci]
│
│ 📌 *Contoh:*
│ ${usedPrefix}${command} Raiden
│ ${usedPrefix}${command} Laut
│
╰═════════════════════`);
        }

        await m.reply("🌙 *Memasuki alam mimpi...*");
        await new Promise(resolve => setTimeout(resolve, 1500));
        await m.reply("✨ *Mengumpul esensi mimpi...*");
        await new Promise(resolve => setTimeout(resolve, 1500));

        const dreamData = generateDreamWorld(text);
        const dreamInterpretation = interpretDream(dreamData);

        const caption = `╭═══❯ *DUNIA MIMPI* ❮═══
│
│ 👤 *Penjelajah:* ${text}
│ 🌙 *Tahap Mimpi:* ${dreamData.level}
│ 🎭 *Teras Mimpi:*
│ ${dreamData.core}
│ 🌈 *Elemen Mimpi:*
│ ${dreamData.elements.join('\n│ ')}
│ 🎪 *Peristiwa Mimpi:*
│ ${dreamData.events.join('\n│ ')}
│ 🌟 *Pertemuan Istimewa:*
│ ${dreamData.encounters.join('\n│ ')}
│ 💫 *Kuasa Mimpi:*
│ ${dreamData.powers.join('\n│ ')}
│ 🔮 *Mesej Mimpi:*
│ ${dreamData.message}
│ 📝 *Tafsiran Mimpi:*
│ ${dreamInterpretation}
│
╰═════════════════════

🎯 *Kualiti Mimpi:* ${dreamData.quality}
⏰ *Masa Mimpi:* ${moment().tz('Asia/Kuala_Lumpur').format('HH:mm:ss')}`;

        return m.reply(caption);

    } catch (error) {
        console.error('Error in dreamworld command:', error);
        return m.reply(`╭══════════════════════
│ ❌ *Terdapat Ralat*
│ Sila cuba sebentar lagi
╰══════════════════════`);
    }
};

function generateDreamWorld(seed) {
    const dreamLevels = ['Lucid ✨', 'Mystic 🌟', 'Ethereal 💫', 'Divine 🌙', 'Legendary 🎇'];
    const dreamQualities = ['Mimpi Aman 😌', 'Mimpi Pengembaraan 🚀', 'Visi Mistik 🔮', 'Mimpi Ramalan 📖', 'Perjalanan Epik 🗺️'];

    const elementsList = [
        '🌊 Lautan Kristal Bercahaya',
        '🌈 Pelangi Mengambang',
        '🌺 Taman Melayang',
        '⭐ Konstelasi Hidup',
        '🌙 Bulan Kembar',
        '🎪 Sirkus Dimensi',
        '🏰 Istana Awan',
        '🌋 Gunung Prisma',
        '🎭 Teater Bayang',
        '🎪 Portal Masa'
    ];

    const eventsList = [
        '🦋 Rama-rama membawa mesej rahsia',
        '🎭 Topeng menari sendiri',
        '🌊 Hujan bintang jatuh ke laut',
        '🎪 Perarakan makhluk ajaib',
        '🌺 Bunga menyanyi lagu kuno',
        '🎨 Lukisan menjadi hidup',
        '🎵 Muzik kelihatan sebagai warna',
        '⚡ Kilat membentuk tangga ke langit',
        '🌈 Pelangi bertukar menjadi jambatan',
        '🕰️ Masa berpusing ke belakang'
    ];

    const encountersList = [
        '🐉 Naga Pelangi Bijaksana',
        '🧙‍♂️ Ahli Sihir Bintang',
        '🦊 Musang Semangat Sembilan Ekor',
        '🧝‍♀️ Peri Pembawa Mimpi',
        '🦁 Singa Kristal',
        '🐋 Ikan Paus Terbang Mistis',
        '🦅 Burung Phoenix Masa',
        '🐢 Penyu Pembawa Dunia',
        '🦄 Unicorn Dimensi',
        '👻 Semangat Pelindung'
    ];

    const powersList = [
        '✨ Mengawal Masa',
        '🌊 Berbicara dengan Elemen',
        '🎭 Shapeshifting',
        '🌈 Manipulasi Realiti',
        '👁️ Penglihatan Masa Depan',
        '🎪 Teleportasi Dimensi',
        '🌙 Penyembuhan Rohani',
        '⚡ Tenaga Kosmik',
        '🎨 Ciptaan Segera',
        '💫 Telepati Universal'
    ];

    const messagesList = [
        'Perjalananmu akan membawa perubahan besar',
        'Rahsia lama akan terdedah tidak lama lagi',
        'Kekuatan tersembunyi akan segera bangkit',
        'Takdir baru menanti di ufuk',
        'Hubungan rohani akan menguat',
        'Transformasi besar akan berlaku',
        'Pencerahan akan datang dari arah yang tidak dijangka',
        'Misi penting akan segera bermula',
        'Tanda baik dalam perjalanan hidupmu',
        'Kebijaksanaan baru akan ditemui'
    ];

    const seedNum = Array.from(seed).reduce((acc, char) => acc + char.charCodeAt(0), 0);

    const randomize = (arr) => arr[Math.floor((seedNum * arr.length) / 1000) % arr.length];
    const randomMultiple = (arr, count) => {
        const shuffled = [...arr].sort(() => (seedNum * 0.5) - 0.5);
        return shuffled.slice(0, count);
    };

    return {
        level: randomize(dreamLevels),
        quality: randomize(dreamQualities),
        core: generateDreamCore(seed),
        elements: randomMultiple(elementsList, 3),
        events: randomMultiple(eventsList, 3),
        encounters: randomMultiple(encountersList, 2),
        powers: randomMultiple(powersList, 2),
        message: randomize(messagesList)
    };
}

function generateDreamCore(seed) {
    const cores = [
        '🌌 Dunia Selari Mistis',
        '🎪 Alam Keajaiban Antara',
        '🌙 Dimensi Cahaya Perak',
        '✨ Negeri Kristal Mengambang',
        '🌈 Alam Pelangi Abadi',
        '🎭 Teater Realiti Mimpi',
        '⚡ Zon Masa Misteri',
        '🌺 Taman Eden Ajaib',
        '🌊 Lautan Bintang Mistis',
        '🏰 Istana Awan Berkilau'
    ];

    return cores[Math.floor((Array.from(seed).reduce((acc, char) => acc + char.charCodeAt(0), 0) * cores.length) / 1000) % cores.length];
}

function interpretDream(dreamData) {
    const interpretations = [
        'Mimpi ini menunjukkan potensi kreatif yang luar biasa dalam dirimu',
        'Perjalanan rohani yang bermakna akan segera bermula',
        'Kekuatan tersembunyi dalam dirimu akan terdedah',
        'Masa transformasi besar sedang menghampiri',
        'Hubungan istimewa akan terbentuk tidak lama lagi',
        'Pengembaraan baru yang menakjubkan menanti',
        'Kebijaksanaan lama akan membuka jalan barumu',
        'Takdir istimewa sedang menuju ke arahmu',
        'Misi kehidupan yang penting akan segera terdedah',
        'Pencerahan rohani akan datang dalam bentuk yang tidak dijangka'
    ];

    const seedValue = dreamData.level + dreamData.core;
    return interpretations[Math.floor((Array.from(seedValue).reduce((acc, char) => acc + char.charCodeAt(0), 0) * interpretations.length) / 1000) % interpretations.length];
}

handler.help = ['dreamworld', 'dream', 'mimpi', 'dreamexp'];
handler.tags = ['fun'];
handler.command = /^dreamworld|dream|mimpi$/i;
handler.group = true;
handler.limit = 1;

module.exports = handler;
