let handler = async (m, { conn, text, usedPrefix, command }) => {
    conn.menfess = conn.menfess ? conn.menfess : {}
    if (!text) throw `*Cara penggunaan:*\n\n${usedPrefix + command} nombor|nama penghantar|mesej\n\n*Nota:* nama penghantar boleh nama samaran atau anonymous.\n\n*Contoh:* ${usedPrefix + command} ${m.sender.split`@`[0]}|Anonymous|Hai.`;
    let [jid, name, pesan] = text.split('|');
    if ((!jid || !name || !pesan)) throw `*Cara penggunaan:*\n\n${usedPrefix + command} nombor|nama penghantar|mesej\n\n*Nota:* nama penghantar boleh nama samaran atau anonymous.\n\n*Contoh:* ${usedPrefix + command} ${m.sender.split`@`[0]}|Anonymous|Hai.`;
    jid = jid.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
    let data = (await conn.onWhatsApp(jid))[0] || {};
    if (!data.exists) throw 'Nombor tidak berdaftar di WhatsApp.';
    if (jid == m.sender) throw 'Tidak boleh menghantar mesej menfess kepada diri sendiri.'
    let mf = Object.values(conn.menfess).find(mf => mf.status === true)
    if (mf) return !0
        let id = + new Date
        let teks = `Hai @${data.jid.split("@")[0]}, awak menerima mesej Menfess.\n\nDaripada: *${name}*\nMesej: \n${pesan}\n\nNak balas mesej ini? Boleh sahaja. Taip mesej awak lalu hantar, nanti saya sampaikan kepada *${name}*.`.trim();
        await conn.sendMessage(data.jid, {
            image: { url: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRIyz1dMPkZuNleUyfXPMsltHwKKdVddTf4-A&usqp=CAU' },
            caption: teks,
            mentions: [data.jid]
        }, {}).then(() => {
            m.reply('Berjaya menghantar mesej menfess.')
            conn.menfess[id] = {
                id,
                dari: m.sender,
                nama: name,
                penerima: data.jid,
                pesan: pesan,
                status: false
            }
            return !0
        })
}
handler.tags = ['fun']
handler.help = ['menfess']
handler.command = /^(menfess|menfes)$/i
handler.private = true

module.exports = handler
