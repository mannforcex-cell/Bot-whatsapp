let handler = async (m, { conn, text }) => {
  function no(number) {
    return number.replace(/\s/g, '').replace(/([@+-])/g, '')
  }

  text = no(text)

  if (isNaN(text)) {
    var number = text.split`@`[1]
  } else if (!isNaN(text)) {
    var number = text
  }

  if (number.length > 15 || (number.length < 9 && number.length > 0)) return conn.reply(m.chat, `*Tag target!*`, m)

  if (!text && !m.quoted) {
    user = m.sender
    orang = "Awak"
  } else if (text) {
    var user = number + '@s.whatsapp.net'
    orang = "Orang yang awak tag"
  } else if (m.quoted.sender) {
    var user = m.quoted.sender
    orang = "Orang yang awak tag"
  } else if (m.mentionedJid) {
    var user = number + '@s.whatsapp.net'
    orang = "Orang yang awak tag"
  }

  if (typeof global.db.data.users[user] == "undefined") {
    return m.reply("*Orang yang awak tag tidak berdaftar dalam Bot.*")
  }

  if (typeof global.db.data.users[global.db.data.users[user].pasangan] == "undefined" && global.db.data.users[user].pasangan != "") {
    return m.reply("*Pasangan/gebetan target tidak berdaftar dalam bot.*")
  }

  if (global.db.data.users[user].pasangan == "") {
    conn.reply(m.chat, `*${orang} tiada pasangan dan tidak sedang menembak sesiapa*\n\n*Taip /tembak @user untuk tembak seseorang*`, m)
  } else if (global.db.data.users[global.db.data.users[user].pasangan].pasangan != user) {
    conn.reply(m.chat, `*${orang} sedang digantung oleh @${global.db.data.users[user].pasangan.split('@')[0]} kerana belum diterima atau ditolak*\n\n*Taip .ikhlasin untuk padamkan nama dia dari hati awak*`, m, {
      contextInfo: {
        mentionedJid: [global.db.data.users[user].pasangan]
      }
    })
  } else {
    conn.reply(m.chat, `*${orang} sedang berpasangan dengan @${global.db.data.users[user].pasangan.split('@')[0]} 🥳🥳*`, m, {
      contextInfo: {
        mentionedJid: [global.db.data.users[user].pasangan]
      }
    })
  }
}
handler.help = ['cekpacar']
handler.tags = ['fun']
handler.command = /^(cekpacar)$/i
handler.limit = true
handler.group = true
handler.fail = null
module.exports = handler
