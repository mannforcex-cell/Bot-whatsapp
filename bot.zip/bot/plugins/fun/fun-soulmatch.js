const moment = require('moment-timezone');

let handler = async (m, { text, conn }) => {
    if (!text) {
        return m.reply(`╭═══❯ *JIWA SEPADAN* ❮═══
│
│ ❌ Masukkan 2 nama untuk dianalisis!
│ 
│ 📝 *Format:*
│ .soulmatch nama1|nama2
│
│ 📌 *Contoh:*
│ .soulmatch Raiden|Mei
│
╰════════════════════`);
    }

    try {
        const [nama1, nama2] = text.split("|").map(name => name.trim());

        if (!nama2) {
            return m.reply("❌ Format salah! Guna tanda '|' untuk asingkan nama\nContoh: .soulmatch Raiden|Mei");
        }

        const generateSoulData = (name, previousElement) => {
            const numerologyValue = name.toLowerCase().split('')
                .map(char => char.charCodeAt(0) - 96)
                .reduce((a, b) => a + b, 0) % 9 + 1;

            const elements = ['Api 🔥', 'Air 💧', 'Tanah 🌍', 'Angin 🌪️', 'Petir ⚡', 'Ais ❄️', 'Cahaya ✨', 'Bayang 🌑'];

            let element;
            do {
                element = elements[Math.floor(Math.random() * elements.length)];
            } while (element === previousElement);

            const zodiacSigns = ['♈ Aries', '♉ Taurus', '♊ Gemini', '♋ Cancer', '♌ Leo', '♍ Virgo',
                                 '♎ Libra', '♏ Scorpio', '♐ Sagittarius', '♑ Capricorn', '♒ Aquarius', '♓ Pisces'];
            const zodiac = zodiacSigns[Math.floor(Math.random() * zodiacSigns.length)];

            return { numerologyValue, element, zodiac };
        };

        let previousElement = null;
        const soul1 = generateSoulData(nama1, previousElement);
        previousElement = soul1.element;

        const soul2 = generateSoulData(nama2, previousElement);

        const calculateCompatibility = () => Math.floor(Math.random() * 100) + 1;

        const compatibility = calculateCompatibility();

        const soulTypes = [
            "Pemimpin Yang Berani", "Penyeimbang Bijaksana", "Pencipta Ekspresif", "Pembina Teguh",
            "Petualang Bebas", "Pelindung Setia", "Pemikir Mistis", "Penakluk Kuat", "Pejuang Murni"
        ];

        const getRandomSoulType = () => soulTypes[Math.floor(Math.random() * soulTypes.length)];

        const getMatchDescription = (score) => {
            if (score >= 90) return "💫 Jodoh Sejati";
            if (score >= 80) return "✨ Keserasian Sempurna";
            if (score >= 70) return "🌟 Hubungan Kuat";
            if (score >= 60) return "⭐ Potensi Baik";
            if (score >= 50) return "🌙 Perlu Usaha";
            return "🌑 Cabaran Berat";
        };

        const generateSoulReading = (compatibility) => {
            const readings = [
                compatibility >= 90 ? [
                    "│ ✨ Jiwa kalian mempunyai hubungan yang sangat",
                    "│    istimewa dan langka",
                    "│ 🌟 Takdir telah merancang pertemuan ini",
                    "│ 💫 Resonansi jiwa kalian mencipta",
                    "│    keserasian sempurna"
                ] : compatibility >= 80 ? [
                    "│ 🌟 Ada chemistry yang sangat kuat antara",
                    "│    kalian",
                    "│ ✨ Jiwa kalian saling melengkapi dengan",
                    "│    cara yang unik",
                    "│ 💫 Pertemuan kalian membawa tenaga positif"
                ] : compatibility >= 70 ? [
                    "│ 🌙 Potensi hubungan yang mendalam dan bermakna",
                    "│ ✨ Perbezaan kalian justru mencipta",
                    "│    keserasian",
                    "│ 💫 Ada pelajaran berharga dalam pertemuan",
                    "│    ini"
                ] : compatibility >= 60 ? [
                    "│ 🌟 Perlu masa untuk saling memahami",
                    "│ 💫 Setiap cabaran akan memperkuat ikatan",
                    "│ ✨ Fokus pada perkara positif dari perbezaan",
                    "│    kalian"
                ] : compatibility >= 50 ? [
                    "│ 🌙 Perlu usaha lebih untuk keserasian",
                    "│ ✨ Cabaran akan menguji kesungguhan",
                    "│ 💫 Komunikasi jadi kunci utama hubungan"
                ] : [
                    "│ 🌑 Perbezaan yang ketara dalam tenaga",
                    "│    jiwa",
                    "│ ✨ Perlu banyak penyesuaian dan pengertian",
                    "│ 💫 Setiap hubungan ada maksud tersendiri"
                ]
            ];

            return readings[0].join('\n');
        };

        const caption = `╭═══❯ *JIWA SEPADAN* ❮═══
│
│ 👤 *${nama1}*
│ ├ 🔮 Jenis Jiwa: ${getRandomSoulType()}
│ ├ 🌟 Elemen: ${soul1.element}
│ └ 🎯 Zodiak: ${soul1.zodiac}
│
│ 👤 *${nama2}*
│ ├ 🔮 Jenis Jiwa: ${getRandomSoulType()}
│ ├ 🌟 Elemen: ${soul2.element}
│ └ 🎯 Zodiak: ${soul2.zodiac}
│
│ 💫 *KESERASIAN*
│ ├ 📊 Skor: ${compatibility}%
│ └ 🎭 Status: ${getMatchDescription(compatibility)}
│
│ 🔮 *Bacaan Jiwa*
${generateSoulReading(compatibility)}
│
╰════════════════════

📅 *Tarikh Analisis:* ${moment().tz('Asia/Kuala_Lumpur').format('DD/MM/YYYY HH:mm:ss')}`;

        return m.reply(caption);

    } catch (error) {
        console.error('Error in soulmatch command:', error);
        return m.reply(`╭══════════════════════
│ ❌ *Terdapat Ralat*
│ Sila cuba sebentar lagi
╰═════════════════════`);
    }
};

handler.help = ['soulmatch'];
handler.tags = ['fun'];
handler.command = /^soulmatch$/i;
handler.group = true;
handler.limit = 1;

module.exports = handler;
