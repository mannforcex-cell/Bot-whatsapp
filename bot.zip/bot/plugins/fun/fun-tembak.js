let handler = async (m, { conn, usedPrefix, text }) => {
  let who
  if (m.quoted) who = m.quoted.sender
  else if (m.mentionedJid?.[0]) who = m.mentionedJid[0]
  else if (text) {
    let num = text.replace(/[^0-9]/g, '')
    if (num.length > 5 && num.length < 20) who = num + '@s.whatsapp.net'
  }

  if (!who) return conn.reply(m.chat, `Tag atau reply orang yang nak ditembak!\nContoh: ${usedPrefix}tembak @tag`, m)

  if (who === m.sender) return conn.reply(m.chat, `Tak boleh tembak diri sendiri!`, m)

  let user = global.db.data.users[who]
  let sender = global.db.data.users[m.sender]

  if (!user) return conn.reply(m.chat, `Target tidak berdaftar dalam pangkalan data`, m)

  const format = num => num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')

  if (sender.pasangan && sender.pasangan !== who && global.db.data.users[sender.pasangan]?.pasangan === m.sender) {
    let denda = Math.ceil(sender.exp / 1000 * 20)
    sender.exp -= denda
    return conn.reply(m.chat, `Awak dah ada pasangan @${sender.pasangan.split('@')[0]}!\nPutus dulu dengan ${usedPrefix}putus @tag\nDenda curang: ${format(denda)} exp`, m, { mentions: [sender.pasangan] })
  }

  if (user.pasangan && user.pasangan !== m.sender && global.db.data.users[user.pasangan]?.pasangan === who) {
    let denda = Math.ceil(sender.exp / 1000 * 10)
    sender.exp -= denda
    return conn.reply(m.chat, `Dia dah ada pasangan @${user.pasangan.split('@')[0]}!\nDenda: ${format(denda)} exp`, m, { mentions: [user.pasangan] })
  }

  if (user.pasangan === m.sender) {
    sender.pasangan = who
    user.pasangan = m.sender
    return conn.reply(m.chat, `Tahniah! @${m.sender.split('@')[0]} & @${who.split('@')[0]} rasmi berpasangan!\nSemoga kekal`, m, { mentions: [m.sender, who] })
  }

  sender.pasangan = who
  conn.reply(m.chat, `@${who.split('@')[0]} awak ditembak oleh @${m.sender.split('@')[0]}!\n\nTaip *${usedPrefix}terima @${m.sender.split('@')[0]}* untuk terima\nTaip *${usedPrefix}tolak @${m.sender.split('@')[0]}* untuk tolak`, m, { mentions: [who, m.sender] })
}

handler.help = ['tembak @tag']
handler.tags = ['fun']
handler.command = /^(tembak)$/i
handler.group = true

module.exports = handler
