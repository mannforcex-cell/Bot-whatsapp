/* Dibuat oleh VynaaValerie
   Github : https://api.vtech.biz.id
*/

let handler = async (m, { text, usedPrefix, command }) => {
  try {
    let result = await khodamnya();
    let teks = `- Khodam \`@${m.quoted ? m.quoted.sender.split("@")[0] : m.sender.split("@")[0]}\` : ${result.name}\n\n> Penjelasan: ${result.meaning}`;

    if (m.key.fromMe) {
      await m.reply(teks, { edit: m.key, mentions: [m.quoted ? m.quoted.sender : m.sender] });
    } else {
      await m.reply(teks);
    }
  } catch (e) {
    console.error(e);
  }
};

handler.command = handler.help = ['cekkhodam','cekhodam','cekodam'];
handler.tags = ['fun'];
handler.limit = true;

module.exports = handler;

async function khodamnya() {
                const khodams = [
                { name: "Harimau Putih", meaning: "Awak kuat dan berani seperti harimau, kerana nenek moyang mewariskan kekuatan besar kepada awak." },
                { name: "Lampu Tertidur", meaning: "Kelihatan mengantuk tapi sentiasa memberikan cahaya yang hangat" },
                { name: "Panda Ompong", meaning: "Awak menggemaskan dan sentiasa berjaya membuat orang tersenyum dengan keanehan awak." },
                { name: "Itik Getah", meaning: "Awak sentiasa tenang dan ceria, mampu menghadapi gelombang masalah dengan senyuman." },
                { name: "Ninja Turtle", meaning: "Awak lincah dan teguh, bersedia melindungi yang lemah dengan kekuatan awak." },
                { name: "Kucing Peti Sejuk", meaning: "Awak misterius dan sentiasa ada di tempat yang tidak dijangka." },
                { name: "Sabun Wangi", meaning: "Awak sentiasa membawa keharuman dan kesegaran di mana sahaja awak berada." },
                { name: "Semut Kecil", meaning: "Awak pekerja keras dan sentiasa boleh diandalkan dalam situasi apa pun." },
                { name: "Moge Suzuki", meaning: "Awak cepat dan bergaya, sentiasa menjadi tumpuan perhatian." },
                { name: "Cupcake Pelangi", meaning: "Awak manis dan penuh warna, sentiasa membawa kebahagiaan dan keceriaan." },
                { name: "Robot Mini", meaning: "Awak canggih dan sentiasa bersedia membantu dengan kecerdasan tinggi." },
                { name: "Ikan Terbang", meaning: "Awak unik dan penuh kejutan, sentiasa melampaui batasan yang ada." },
                { name: "Ayam Goreng", meaning: "Awak sentiasa disukai dan ditunggu ramai orang, penuh kelezatan dalam setiap langkah." },
                { name: "Lipas Terbang", meaning: "Awak sentiasa mengejutkan dan menggemparkan satu ruangan." },
                { name: "Kambing Ngebor", meaning: "Awak unik dan sentiasa membuat orang ketawa dengan kelakuan pelik awak." },
                { name: "Keropok Rangup", meaning: "Awak sentiasa menjadikan suasana lebih seronok dan nikmat." },
                { name: "Tabung Celengan", meaning: "Awak sentiasa menyimpan kejutan di dalam diri awak." },
                { name: "Almari Lama", meaning: "Awak penuh dengan cerita dan kenangan masa lalu." },
                { name: "Kopi Susu", meaning: "Awak manis dan sentiasa memberi semangat kepada orang di sekeliling." },
                { name: "Penyapu Lidi", meaning: "Awak kuat dan sentiasa boleh diandalkan untuk membersihkan masalah." },
                { name: "Kuda Lumping", meaning: "Awak penuh semangat dan sentiasa tampil berbeza di setiap kesempatan." },
                { name: "Kasut Roda", meaning: "Awak cepat dan lincah, sentiasa bergerak ke hadapan dengan penuh gaya." },
                { name: "Bola Pingpong", meaning: "Awak ringan dan sentiasa menjadikan permainan lebih seronok." },
                { name: "Lumba-lumba", meaning: "Awak bijak dan sentiasa membawa keceriaan dalam lautan kehidupan." },
                { name: "Kucing Gemuk", meaning: "Awak santai dan sentiasa membuat orang tersenyum dengan kelucuan awak." },
                { name: "Iguana Pink", meaning: "Awak eksotik dan sentiasa menarik perhatian dengan warna unik awak." },
                { name: "Bantal Peluk", meaning: "Awak selesa dan sentiasa diperlukan semasa waktu rehat." },
                { name: "Komputer Lama", meaning: "Awak klasik dan penuh dengan pengetahuan dalam diri awak." },
                { name: "Tilam Empuk", meaning: "Awak sentiasa memberikan keselesaan dan ketenangan." },
                { name: "Bola Bekel", meaning: "Awak kecil tapi sentiasa memberikan kebahagiaan dalam setiap permainan." },
                { name: "Aiskrim Pelangi", meaning: "Awak manis dan penuh warna, sentiasa menyegarkan hari-hari." },
                { name: "Biskut Coklat", meaning: "Awak sentiasa membuatkan orang teruja dengan kelezatan awak yang tidak tertahankan." },
                { name: "Nasi Lemak", meaning: "Awak sentiasa membuat orang kenyang dan puas dengan keenakan khas awak." },
                { name: "Roti Bakar", meaning: "Awak sederhana tapi sentiasa membuat orang berasa selesa." },
                { name: "Basikal Ontel", meaning: "Awak klasik dan sentiasa memberikan keseronokan dalam setiap perjalanan." },
                { name: "Sate Kambing", meaning: "Awak sedap dan sentiasa jadi kegemaran di setiap kesempatan." },
                { name: "Kek Cubit", meaning: "Awak kecil tapi sentiasa membuat orang bahagia dengan rasa yang enak." },
                { name: "Bakso Urat", meaning: "Awak kuat dan sentiasa memberikan kenikmatan dalam setiap gigitan." },
                { name: "Air Kelapa", meaning: "Awak segar dan sentiasa menyejukkan di saat-saat panas." },
                { name: "Dumpling Manis", meaning: "Awak sentiasa membuatkan orang teruja dengan rasa khas awak yang lazat." },
                { name: "Teh Tarik Hangat", meaning: "Awak sentiasa menjadikan suasana hangat dan selesa." },
                { name: "Martabak Manis", meaning: "Awak penuh kejutan dengan isi yang manis dan nikmat." },
                { name: "Gula-Gula Getah", meaning: "Awak sentiasa menjadikan suasana lebih ceria dengan kenikmatannya yang kenyal." },
                { name: "Pisang Goreng", meaning: "Awak sentiasa menjadikan suasana lebih hangat dan selesa." },
                { name: "Telur Dadar", meaning: "Awak sederhana tapi sentiasa membuat orang puas dengan kelezatan awak." },
                { name: "Aiskrim Buah", meaning: "Awak segar dan penuh warna, sentiasa menjadikan hari lebih ceria." },
                { name: "Mihun Goreng", meaning: "Awak sentiasa membuat orang kenyang dan puas dengan rasa lazat awak." },
                { name: "Puding Coklat", meaning: "Awak manis dan sentiasa menjadikan suasana lebih selesa." },
                { name: "Gulai Kambing", meaning: "Awak kaya rasa dan sentiasa membuat orang teruja dengan kelezatan awak." },
                { name: "Kue Nastar", meaning: "Awak sentiasa hadir di saat-saat istimewa dengan rasa yang manis dan enak." },
                { name: "Keropok Ikan", meaning: "Awak rangup dan sentiasa menjadikan suasana lebih seronok." },
                { name: "Ais Campur", meaning: "Awak segar dan penuh kejutan dengan campuran rasa yang enak." },
                { name: "Rojak Buah", meaning: "Awak segar dan sentiasa menjadikan suasana lebih hidup dengan rasa pedas dan manisnya." },
                { name: "Sup Ayam", meaning: "Awak sentiasa menghangatkan dan memuaskan dengan kuah yang lazat." },
                { name: "Tahu Bulat", meaning: "Awak sentiasa hadir di momen yang tepat dengan rasa yang enak." },
                { name: "Kerepek Ubi", meaning: "Awak rangup dan sentiasa menjadikan suasana lebih seronok." },
                { name: "Kacang Goreng", meaning: "Awak sentiasa jadi makanan ringan kegemaran di setiap kesempatan." },
                { name: "Daging Masak Merah", meaning: "Awak kaya rasa dan sentiasa membuat orang teruja dengan kelezatan awak." },
                { name: "Sate Padang", meaning: "Awak sentiasa membuat orang kenyang dan puas dengan rasa khas awak." },
                { name: "Nasi Uduk", meaning: "Awak sentiasa membuat orang kenyang dan puas dengan rasa gurih awak." },
                { name: "Cendol", meaning: "Awak segar dan sentiasa menjadikan suasana lebih sejuk di saat-saat panas." },
                { name: "Onde-onde", meaning: "Awak sentiasa hadir di saat-saat istimewa dengan rasa yang manis dan enak." },
                { name: "Kolak Pisang", meaning: "Awak manis dan sentiasa menjadikan suasana lebih hangat dan selesa." },
                { name: "Harimau Belang", meaning: "Awak misterius dan kuat, seperti harimau yang jarang kelihatan tapi sentiasa berwaspada." },
                { name: "Kuda Emas", meaning: "Awak berharga dan kuat, bersedia berlari menuju kejayaan." },
                { name: "Helang Biru", meaning: "Awak mempunyai visi yang tajam dan boleh melihat peluang dari jauh." },
                { name: "Mi Goreng", meaning: "Sentiasa membuat kenyang dan bahagia" },
                { name: "Aiskrim Cair", meaning: "Sentiasa mencairkan suasana dengan rasa manisnya" },
                { name: "Bakso Ulet", meaning: "Sentiasa gigih dan bulat dalam menghadapi masalah" },
                { name: "Gam Super", meaning: "Sentiasa melekat dalam situasi yang rumit" },
                { name: "Kicap Manis", meaning: "Sentiasa memberikan sentuhan manis dalam hidup" },
                { name: "Sabun Mandi", meaning: "Sentiasa bersih dan wangi" },
                { name: "Kopi Tumpah", meaning: "Sentiasa bersemangat, tapi kadang-kadang berselerak" },
                { name: "Basikal Ontel", meaning: "Sentiasa klasik dan sederhana" },
                { name: "Roti Bakar", meaning: "Sentiasa hangat dan enak" },
                { name: "Kucing Kampung", meaning: "Sentiasa berdikari dan penuh petualangan" },
                { name: "Jamu Pahit", meaning: "Sentiasa memberi kekuatan walaupun tidak enak pada mulanya" },
                { name: "Teh Celup", meaning: "Sentiasa memberikan rasa hangat di hati" },
                { name: "Beg Plastik", meaning: "Sentiasa ringan dan praktikal" },
                { name: "Air Kelapa", meaning: "Sentiasa segar dan menyegarkan" },
                { name: "Motor Lama", meaning: "Sentiasa setia dan tahan lasak" },
                { name: "Mi Segera", meaning: "Sentiasa cepat dan mengenyangkan" },
                { name: "Kek Kukus", meaning: "Sentiasa lembut dan manis" },
                { name: "Tahu Bulat", meaning: "Sentiasa enak di segala suasana" },
                { name: "Nasi Uduk", meaning: "Sentiasa sesuai di segala masa" },
                { name: "Susu Pekat Manis", meaning: "Sentiasa menambah kenikmatan" },
                { name: "Kopi Hitam", meaning: "Sentiasa memberi semangat di waktu pagi" },
                { name: "Kacang Goreng", meaning: "Sentiasa seronok untuk dijadikan makanan ringan" },
                { name: "Ayam Goreng Tepung", meaning: "Sentiasa rangup dan nikmat" },
                { name: "Sambal Belacan", meaning: "Sentiasa pedas dan menggigit" },
                { name: "Nasi Campur", meaning: "Sentiasa mengenyangkan dan lazat" },
                { name: "Cendol", meaning: "Sentiasa segar di tengah hari" },
                { name: "Gado-Gado", meaning: "Sentiasa penuh warna dan rasa" },
                { name: "Pisang Goreng", meaning: "Sentiasa manis dan gurih" },
                { name: "Martabak Manis", meaning: "Sentiasa lazat dan memanjakan lidah" },
                { name: "Bubur Ayam", meaning: "Sentiasa hangat dan mengenyangkan" },
                { name: "Sup Ayam", meaning: "Sentiasa kaya rasa dan gurih" },
                { name: "Nasi Padang", meaning: "Sentiasa penuh dengan kenikmatan" },
                { name: "Rendang Daging", meaning: "Sentiasa empuk dan kaya rempah" },
                { name: "Nasi Goreng", meaning: "Sentiasa praktikal dan enak" },
                { name: "Bakmi Jawa", meaning: "Sentiasa menggugah selera" },
                { name: "Sate Ayam", meaning: "Sentiasa enak di segala acara" },
                { name: "Gulai Kambing", meaning: "Sentiasa kaya rasa dan lazat" },
                { name: "Rawon Sapi", meaning: "Sentiasa gelap dan nikmat" },
                { name: "Ikan Bakar", meaning: "Sentiasa gurih dan enak" },
                { name: "Pepes Tahu", meaning: "Sentiasa lazat dan berkhasiat" },
                { name: "Tempe Mendoan", meaning: "Sentiasa gurih dan rangup" },
                { name: "Kerepek Ubi", meaning: "Sentiasa rangup dan menggoda" },
                { name: "Jus Avokado", meaning: "Sentiasa segar dan menyihatkan" },
                { name: "Ais Teler", meaning: "Sentiasa segar dan nikmat" },
                { name: "Bubur Kacang Hijau", meaning: "Sentiasa hangat dan mengenyangkan" },
                { name: "Pau", meaning: "Sentiasa lembut dan enak" },
                { name: "Pempek", meaning: "Sentiasa gurih dan kenyal" },
                { name: "Sosej Bakar", meaning: "Sentiasa enak di segala suasana" },
                { name: "Sandal Jepun", meaning: "Sentiasa santai dan selesa" },
                { name: "Bantal Kapuk", meaning: "Sentiasa empuk dan lembut" },
                { name: "Pemadam Getah", meaning: "Sentiasa bersedia menghapus kesilapan" },
                { name: "Cermin Retak", meaning: "Sentiasa memberikan pantulan yang unik" },
                { name: "Pen Bocor", meaning: "Sentiasa meninggalkan kesan" },
                { name: "Timba Bocor", meaning: "Sentiasa berfungsi walaupun tidak sempurna" },
                { name: "Kipas Angin", meaning: "Sentiasa memberikan angin segar" },
                { name: "Pembuka Tin", meaning: "Sentiasa berguna bila diperlukan" },
                ];

  const index = Math.floor(Math.random() * khodams.length);
  return khodams[index];
}
