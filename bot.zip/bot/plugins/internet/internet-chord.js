let fetch = require('node-fetch');

let handler = async (m, { text, command, usedPrefix }) => {
if (!text) throw `Contoh: ${usedPrefix + command} Sejati Exist`
m.reply(wait)
try {
    let response = await fetch(`https://api.vtech.biz.id/api/search/chord?song=${text}&apikey=${vtech}`);
    let data = await response.json();

    if (data.status && data.result) {
        let txt = `乂 *C H O R D  M U S I C*\n\n`;
        txt += `◦ *Tajuk:* ${data.result.title ? data.result.title : text}\n`;
        txt += `◦ *Chord:* ${data.result.chord ? data.result.chord : 'Tidak dijumpai!'}\n\n`;
        text += `\n`;
        await m.reply(txt);
    } else {
        await m.reply('Lagu tidak dijumpai!')
    }
  } catch (error) {
    throw eror
 }
}

handler.help = ['chord <tajuk lagu>']
handler.tags = ['internet']
handler.command = /^(chord)$/i
handler.limit = true
module.exports = handler
