const fetch = require('node-fetch');

const handler = async (m, { conn, command, text }) => {
  if (!text) return conn.reply(m.chat, 'Masukkan teks untuk dicari!', m);

  try {
    await m.reply(wait)
    const response = await fetch(`https://api.vtech.biz.id/api/search/google?text1=${encodeURIComponent(text)}&apikey=${vtech}`);
    const data = await response.json();

    if (!data.status || !data.result?.length) throw new Error('Carian gagal atau tiada keputusan');

    const msg = data.result
      .map(({ title, url, snippet }, index) =>
        `${index + 1}. *${title}*\n🌐 ${url}\n📝 ${snippet || 'Tiada penerangan tersedia'}`
      )
      .join('\n\n');

    const caption = `🔍 *Keputusan Carian: ${text}*\n\n${msg}`;

    await conn.sendMessage(m.chat, {
      image: { url: 'https://a.top4top.io/p_37802zcmd1.png' },
      caption: caption,
      mentions: [m.sender]
    }, { quoted: m });
  } catch (e) {
    await conn.reply(m.chat, eror, m);
  }
};

handler.help = ['google <carian>'];
handler.tags = ['internet'];
handler.command = /^google$/i;
handler.limit = true;

module.exports = handler;
