let handler = async(m, {conn, command, usedPrefix, text}) => {
  let fail = 'format salah, contoh: ' +usedPrefix+command+ ' Bot|1. Masak'
  global.db.data.users[m.sender].catatan = global.db.data.users[m.sender].catatan || []
  let catatan = global.db.data.users[m.sender].catatan
  let split = text.split('|')
  let title = split[0]
  let isi = split[1]
  if (catatan.includes(title)) return m.reply('Tajuk tidak tersedia!\n\nSebab: Sudah digunakan')
  if (!title || !isi) return m.reply(fail)
  let cttn = {
    'title': title,
    'isi': isi
  }
  global.db.data.users[m.sender].catatan.push(cttn)
  conn.reply(m.chat, `Catatan berjaya dibuat!\nUntuk melihat catatan. Taip: ${usedPrefix}lihatcatatan`, m, false, {
    contextInfo: {
      mentionedJid: conn.parseMention(text)
    }
  })
}

handler.help = ['buatcatatan <tajuk|isi>']
handler.tags = ['internet']
handler.command = /^buatcatatan$/i

module.exports = handler
