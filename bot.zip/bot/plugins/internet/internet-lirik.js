let fetch = require("node-fetch");
let handler = async (m, {
    conn,
    text,
    usedPrefix,
    command
}) => {
    if (!text) throw `Contoh: ${usedPrefix}${command} Jiwa yang bersedih`
    try {
        let data = await (await fetch(`https://api.vtech.biz.id/api/search/lirik?lirik=${text}&apikey=${vtech}`)).json()
        let caption = `
${data.result.lyrics}

ℹ️ Maklumat lanjut:
🔗 ${data.result.image}
🎤 Artis: ${data.result.artist}`

        await conn.sendMessage(m.chat, {
            image: { url: data.result.image },
            caption: caption,
            mentions: [m.sender]
        }, { quoted: m })
    } catch (e) {
        console.log(e)
        m.reply('Terdapat ralat, sila cuba lagi nanti')
    }
}

handler.help = ['lirik'].map(v => v + ' <Tajuk>')
handler.tags = ['internet']
handler.command = /^(lirik|lyrics|lyric)$/i

module.exports = handler
