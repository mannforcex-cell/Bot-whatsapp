const fetch = require('node-fetch');

let handler = async (m, { text, usedPrefix, command }) => {
    if (!text) throw `Penggunaan:\n${usedPrefix + command} <teks>\n\nContoh:\n${usedPrefix + command} Kuala Lumpur`;
    try {
        let res = await fetch(`https://api.vtech.biz.id/api/tools/cuaca?query=${encodeURIComponent(text)}&apikey=${vtech}`);
        if (!res.ok) throw 'Lokasi tidak dijumpai';
        let json = await res.json();
        if (!json.status || json.code !== 200) throw eror;
        let result = json.result;
        m.reply(`Lokasi: ${result.location}\nNegara: ${result.country}\nCuaca: ${result.weather}\nSuhu semasa: ${result.currentTemp}\nSuhu tertinggi: ${result.maxTemp}\nSuhu terendah: ${result.minTemp}\nKelembapan: ${result.humidity}\nAngin: ${result.windSpeed}`);
    } catch (error) {
        m.reply('Terdapat ralat semasa mencari maklumat cuaca, sila cuba lagi nanti');
    }
};

handler.help = ['cuaca'];
handler.tags = ['internet'];
handler.command = /^(cuaca|weather)$/i;

module.exports = handler;
