const fetch = require('node-fetch');

let handler = async (m, { text, usedPrefix, command }) => {
    if (!text) throw `Penggunaan:\n${usedPrefix + command} <nama kawasan>\n\nContoh:\n${usedPrefix + command} Petaling Jaya`;
    try {
        let res = await fetch(`https://api.vtech.biz.id/api/search/kodepos?query=${encodeURIComponent(text)}&apikey=${vtech}`);
        if (!res.ok) throw 'Data tidak dijumpai';
        let json = await res.json();
        if (!json.status || json.code !== 200) throw eror;
        let result = json.result;
        if (result.length === 0) throw 'Poskod tidak dijumpai';

        let message = result.map((item, index) =>
            `${index + 1}. Negeri: ${item.province}\nBandar: ${item.city}\nDaerah: ${item.district}\nKampung: ${item.village}\nPoscode: ${item.postalCode}`
        ).join('\n\n');

        m.reply(message);
    } catch (error) {
        m.reply('Terdapat ralat semasa mencari poskod, sila cuba lagi nanti');
    }
};

handler.help = ['kodepos'];
handler.tags = ['internet'];
handler.command = /^(kodepos)$/i;

module.exports = handler;
