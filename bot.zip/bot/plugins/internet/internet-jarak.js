const fetch = require('node-fetch');

let handler = async (m, {
    conn,
    text,
    usedPrefix,
    command
}) => {
    var [from, to] = text.split`|`
    if (!(from && to)) throw `Contoh: ${usedPrefix + command} kualalumpur|johorebahru`

    try {
        let data = await fetch(`https://api.vtech.biz.id/api/search/jarak?from=${from}&to=${to}&apikey=${vtech}`);
        let json = await data.json();

        if (json.status) {
            let message = json.message;
            let detail = message.detail;
            let asal = message.asal;
            let tujuan = message.tujuan;
            let estimasiBiayaBBM = message.estimasi_biaya_bbm;
            let arahjalan = message.arah_penunjuk_jalan;
            let petaStatis = message.peta_statis;
            let rute = message.rute;

            let responseText = `🛣️ *Jarak*:\n\n` +
                `*Butiran Perjalanan:* ${detail}\n` +
                `*Asal:* ${asal.nama}, ${asal.alamat}, ${asal.negara}\n` +
                `*Destinasi:* ${tujuan.nama}, ${tujuan.alamat}, ${tujuan.negara}\n` +
                `*Anggaran Kos Minyak:* ${estimasiBiayaBBM.total_biaya} (Liter: ${estimasiBiayaBBM.total_liter})\n\n` +
                `🗺️ *Arah Perjalanan:*`;

            arahjalan.forEach(step => {
                responseText += `\n${step.langkah}. ${step.instruksi} - ${step.jarak}`;
            });

            responseText += `\n\n📍 *Peta Statik:* ${petaStatis}\n` +
                `🛤️ *Laluan:* ${rute}`;

            let fetch_buff = await fetch(petaStatis);
            let buff = await fetch_buff.buffer();

            await conn.sendFile(m.chat, buff, 'jarak.png', responseText, m);
        } else {
            throw `🚩 *Jarak Tidak Dijumpai*`;
        }
    } catch (error) {
        throw `🚩 *Jarak Tidak Dijumpai*`;
    }
}

handler.command = handler.help = ['jarak'];
handler.tags = ['internet'];
handler.limit = true;

module.exports = handler;
