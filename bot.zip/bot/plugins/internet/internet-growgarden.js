let fetch = require('node-fetch');

let handler = async (m, { usedPrefix, command, text }) => {
    try {
        if (command === 'growgarden' && !text) {
            m.reply(`Sila nyatakan subcommand: \`stock\` atau \`weather\`\nContoh: \`${usedPrefix + command} stock\` atau \`${usedPrefix + command} weather\``);
            return;
        }
        m.reply(wait);
        if (text.toLowerCase() === 'stock') {
            let res = await (await fetch(`https://api.vtech.biz.id/api/webzone/grow-and-garden-stock?apikey=${vtech}`)).json();
            let content = `*🌱 G R O W  &  G A R D E N  S T O C K S 🌱*\n\n`;

            if (res.status && res.result) {
                content += `*🌾 Stok Benih:*\n`;
                res.result.seeds.items.forEach(item => {
                    content += `  ◦ ${item}\n`;
                });
                content += `  *Kemaskini Terakhir*: ${res.result.seeds.lastUpdate}\n`;

                content += `\n*🛠️ Stok Gear:*\n`;
                res.result.gears.items.forEach(item => {
                    content += `  ◦ ${item}\n`;
                });
                content += `  *Kemaskini Terakhir*: ${res.result.gears.lastUpdate}\n`;

                content += `\n*🥚 Stok Telur:*\n`;
                res.result.eggs.items.forEach(item => {
                    content += `  ◦ ${item}\n`;
                });
                content += `  *Kemaskini Terakhir*: ${res.result.eggs.lastUpdate}\n`;

                content += `\n*🎨 Stok Kosmetik:*\n`;
                res.result.cosmetic.items.forEach(item => {
                    content += `  ◦ ${item}\n`;
                });
                content += `  *Kemaskini Terakhir*: ${res.result.cosmetic.lastUpdate}\n`;

                content += `\n*☀️ Stok Summer:*\n`;
                res.result.summer.items.forEach(item => {
                    content += `  ◦ ${item}\n`;
                });
                content += `  *Kemaskini Terakhir*: ${res.result.summer.lastUpdate}\n`;

                content += `\n*🛒 Stok Merchant:*\n`;
                res.result.merchant.items.forEach(item => {
                    content += `  ◦ ${item}\n`;
                });
                content += `  *Kemaskini Terakhir*: ${res.result.merchant.lastUpdate}\n`;
            } else {
                content += 'Data stok tidak dijumpai.';
            }
            await m.reply(content);
        } else if (text.toLowerCase() === 'weather') {
            let res = await (await fetch(`https://api.vtech.biz.id/api/webzone/grow-and-garden-weather?apikey=${vtech}`)).json();
            let content = `*🌦️ G R O W  &  G A R D E N  W E A T H E R 🌦️*\n\n`;

            if (res.status && res.result) {
                content += `📌 *Cuaca Semasa*:\n${res.result.result}\n`;
                content += `⏰ *Tamat*: ${res.result.endsStatus}\n`;
                content += `📅 *Kemaskini Terakhir*: ${res.result.lastUpdate}\n\n`;

                content += `*📜 Sejarah Cuaca:*\n`;
                res.result.history.forEach(item => {
                    content += `  ◦ ${item.description}\n`;
                    content += `    *Tamat*: ${item.endsStatus}\n`;
                    content += `    *Masa*: ${item.time}\n\n`;
                });
            } else {
                content += 'Data cuaca tidak dijumpai.';
            }
            await m.reply(content);
        } else {
            m.reply(`Sila nyatakan subcommand: \`stock\` atau \`weather\`\nContoh: \`${usedPrefix + command} stock\` atau \`${usedPrefix + command} weather\``);
            return;
        }
    } catch (error) {
        throw eror
    }
};

handler.command = ['growgarden'];
handler.tags = ['internet'];
handler.limit = true;
module.exports = handler;
