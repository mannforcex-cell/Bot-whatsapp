let handler = async (m, { conn, text, isROwner, isOwner }) => {
  if (text) {
    if (isROwner) global.conn.welcome = text
    else if (isOwner) conn.welcome = text
    global.db.data.chats[m.chat].sWelcome = text
    m.reply('Mesej selamat datang berjaya ditetapkan\n@user (Mention)\n@subject (Nama Kumpulan)\n@desc (Penerangan Kumpulan)')
  } else throw 'Mana teksnya?'
}
handler.help = ['setwelcome <teks>']
handler.tags = ['owner', 'group']
handler.command = /^setwelcome$/i
handler.botAdmin = true

module.exports = handler
