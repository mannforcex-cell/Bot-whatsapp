let fs = require('fs');

let handler = async (m, { text, usedPrefix, command }) => {
  if (!text) throw `❌ Masukkan laluan fail!\n\nContoh:\n${usedPrefix}sf plugins/folder/nama.js\n(kemudian quote mesej kod yang ingin disimpan)`
  if (!m.quoted || !m.quoted.text) throw `❌ Quote mesej kod yang ingin disimpan!`
  fs.writeFileSync(text, m.quoted.text)
  m.reply(`✅ Fail berjaya disimpan di *${text}*`)
}

handler.help = ['sf <path>']
handler.tags = ['owner']
handler.command = /^sf$/i
handler.rowner = true

module.exports = handler
