let handler = async (m, { conn, participants }) => {
    global.db.data.chats[m.chat].isBanned = true
    m.reply('Berjaya menyekat sembang ini. Bot tidak akan membalas di sembang ini.')
}
handler.help = ['mute']
handler.tags = ['owner']
handler.command = ['mute']
handler.owner = true

module.exports = handler
