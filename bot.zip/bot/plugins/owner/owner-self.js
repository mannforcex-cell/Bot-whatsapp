let handler = async(m, { conn, command }) => {
  let isPublic = command === "public";
  let self = global.opts["self"]

  if (self === !isPublic) return m.reply(`Dah ${!isPublic ? "Self" : "Public"} dari tadi ${m.sender.split("@")[0] === global.owner[1] ? "Kak" : "Bang"} :v`)

  global.opts["self"] = !isPublic

  m.reply(`Berjaya tukar ke mod ${!isPublic ? "Self" : "Public"}!`)
}

handler.help = ["self", "public"]
handler.tags = ["owner"]
handler.owner = true
handler.command = /^(self|public)/i

module.exports = handler
