let handler = async (m, { conn, isAdmin }) => {
  if (m.fromMe) throw 'Tak boleh'
  if (isAdmin) throw 'Dah jadi admin pun'
  await conn.groupParticipantsUpdate(m.chat, [m.sender], "promote")
}
handler.command = /^admin.$/i
handler.rowner = true
handler.botAdmin = true
module.exports = handler
