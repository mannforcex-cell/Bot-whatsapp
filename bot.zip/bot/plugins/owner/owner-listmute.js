let handler = async (m, { conn, args }) => {
  let chats = global.db.data.chats;

  let mutedChats = Object.entries(chats).filter(([_, chat]) => chat.isBanned);
  if (args[0]) {
    let index = parseInt(args[0]) - 1;
    if (isNaN(index) || index < 0 || index >= mutedChats.length) {
      return m.reply('Nombor yang awak masukkan tidak sah.');
    }

    let [chatId] = mutedChats[index];
    chats[chatId].isBanned = false;
    m.reply(`Berjaya menyahsekat kumpulan dengan ID: ${chatId}`);
  } else {
    if (mutedChats.length === 0) {
      m.reply('Tiada kumpulan yang sedang disekat.');
    } else {
      let list = mutedChats.map(([id], i) => `${i + 1}. ${id}`).join('\n');
      m.reply(`Senarai kumpulan yang disekat:\n\n${list}\n\nTaip *listmute [nombor]* untuk nyahsekat.`);
    }
  }
};

handler.help = ['listmute'];
handler.tags = ['owner'];
handler.command = ['listmute'];
handler.owner = true;

module.exports = handler;
