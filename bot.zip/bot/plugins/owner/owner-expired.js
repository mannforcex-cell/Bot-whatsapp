let handler = async (m, { conn, command, usedPrefix, text, participants }) => {
    const groups = Object.keys(conn.chats)
    .filter(key => key.endsWith('@g.us'))
    .map(key => conn.chats[key]);
    let [id, expired] = text.split('|');
    if (!text) {
        const list = groups.map((group, index) => `*${index + 1}.* ${group.subject}`).join('\n');
        const teks = '`S E N A R A I - K U M P U L A N - D I S E R T A I`\n\n'
        let _info = `Arahan salah, contoh: ${usedPrefix + command} <nombor kumpulan>|<bilangan hari>`
        conn.reply(m.chat, `${teks}` + `${list}\n\n${_info}`, m);
    } else if (id && /^\d+$/.test(id)) {
        const index = parseInt(id) - 1;
        if (index >= 0 && index < groups.length) {
            let d = new Date(new Date + 3600000)
            let locale = 'ms'
            let date = d.toLocaleDateString(locale, {
                day: 'numeric',
                month: 'long',
                year: 'numeric'
            })
            let jumlahHari = 86400000 * expired;
            let now = new Date() * 1;
            let group = groups[index];
            let who = group.id
            let namegc = await conn.getName(who);
            switch (command) {
                case "addsewa":
                    if (!expired) throw "Masukkan nombor untuk menambah tempoh sewa"
                    if (!global.db.data.chats[who]) global.db.data.chats[who] = {};

                    if (global.db.data.chats[who].expired && now < global.db.data.chats[who].expired) {
                        global.db.data.chats[who].expired += jumlahHari;
                    } else {
                        global.db.data.chats[who].expired = now + jumlahHari;
                    }
                    let capt = `[ *Notifikasi Kumpulan* ]

*Menambah tempoh sewa bot kumpulan.*
*Nama kumpulan:* ${namegc}
*Id kumpulan:* ${who}
*Tarikh:* ${date}
*Tempoh:* ${msToDate(global.db.data.chats[who].expired - now)}
Hai semua ahli, terima kasih kerana menyewa bot kami`
                    await conn.sendMessage(who, { text: capt })
                    conn.reply(m.chat, `Berjaya menetapkan hari tamat tempoh untuk Kumpulan ini selama ${expired} hari.\n\nKira Undur: ${msToDate(global.db.data.chats[who].expired - now)}`, m);
                    break;
                case 'delsewa':
                    if (!global.db.data.chats[who]) throw `Kumpulan tidak dijumpai dalam pangkalan data.`;
                    global.db.data.chats[who].expired = false;
                    await conn.groupLeave(who)
                    m.reply(`Berjaya membuang hari tamat tempoh untuk Kumpulan ini, dan telah keluar dari kumpulan ini`);
                    break;
                case 'setsewa':
                    let remainingTime = global.db.data.chats[who].expired - new Date() * 1;
                    if (!global.db.data.chats[who]) throw `Kumpulan tidak dijumpai dalam pangkalan data.`;
                    if (!expired) throw "Masukkan nombor untuk mengubah tempoh sewa"
                    m.reply(wait)
                    global.db.data.chats[who].expired = now + jumlahHari;
                    let caption = `[ *Notifikasi Kumpulan* ]

*Perubahan tempoh sewa bot kumpulan.*
*Nama kumpulan:* ${namegc}
*Id kumpulan:* ${who}
*Tarikh:* ${date}
*Tempoh:* ${msToDate(global.db.data.chats[who].expired - now)}
Hai semua ahli, pemilik bot telah mengubah tempoh sewa kumpulan bot`
                    await conn.sendMessage(who, { text: caption });
                    await sleep(3000)
                    conn.reply(m.chat, `Berjaya menetapkan hari tamat tempoh untuk Kumpulan ini selama ${expired} hari.\n\nKira Undur: ${msToDate(global.db.data.chats[who].expired - now)}`, m);
                    break;
            }
        } else {
            conn.reply(m.chat, 'Kumpulan dengan urutan tersebut tidak dijumpai.', m);
        }
    } else {
        const gcname = groups.map((group, index) => `*${index + 1}.* ${group.subject}`).join('\n');
        const tekss = '`S E N A R A I - K U M P U L A N - D I S E R T A I`\n\n'
        let info = `Arahan salah, contoh: ${usedPrefix + command} <nombor kumpulan>|<bilangan hari>`
        conn.reply(m.chat, `${tekss}` + `${gcname}\n\n${info}`, m);
    }
};
handler.help = ['addsewa', 'delsewa', 'setsewa']
handler.tags = ['owner']
handler.command = /^(addsewa|delsewa|setsewa)$/i

handler.owner = true

module.exports = handler

function msToDate(ms) {
    let temp = ms;
    let days = Math.floor(temp / (24 * 60 * 60 * 1000));
    let daysms = temp % (24 * 60 * 60 * 1000);
    let hours = Math.floor((daysms) / (60 * 60 * 1000));
    let hoursms = daysms % (60 * 60 * 1000);
    let minutes = Math.floor((hoursms) / (60 * 1000));
    return `${days} hari ${hours} jam ${minutes} minit`;
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}
