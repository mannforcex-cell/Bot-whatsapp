let handler = async (m, { conn, isOwner, text }) => {
    if (!text) throw 'Masukkan pengguna/id kumpulan yang nak disekat\n\nContoh: .ban 601234567890 atau .ban 2837372829@g.us'
    let who
    if (m.isGroup) {
        if (isOwner) who = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text ? text.replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.chat
        else who = m.chat
    } else {
        if (!isOwner) {
            global.dfail('owner', m, conn)
            throw false
        }
        who = text ? text.replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.chat
    }

    try {
        if (text.endsWith('g.us')) global.db.data.chats[text].isBanned = true
        else global.db.data.users[who].banned = true
        m.reply(`Berjaya sekat! ${await conn.user.name} tidak aktif dalam sembang ${await conn.getName(who) == undefined ? 'ini' : await conn.getName(who)}.`)
    } catch (e) {
        throw `Nombor tiada dalam pangkalan data!`
    }
}
handler.help = ['ban']
handler.tags = ['owner']
handler.command = /^ban(chat)?$/i
handler.owner = true
module.exports = handler
