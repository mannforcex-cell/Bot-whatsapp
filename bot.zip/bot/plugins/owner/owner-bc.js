let handler = async (m, { conn, text }) => {
  if (!text) throw `❌ Masukkan mesej broadcast!\n\nContoh: ${'.'}bc Hai semua!`

  let chats = Object.keys(await conn.chats)
  conn.reply(m.chat, `📢 Menghantar broadcast ke *${chats.length}* sembang...`, m)

  let success = 0
  let fail = 0

  for (let id of chats) {
    await sleep(3000)
    try {
      await conn.sendMessage(id, {
        image: { url: 'https://a.top4top.io/p_37802zcmd1.png' },
        caption: text.trim()
      })
      success++
    } catch (e) {
      fail++
    }
  }

  m.reply(`✅ Broadcast selesai!\n\n📊 Statistik:\n• Berjaya: ${success}\n• Gagal: ${fail}`)
}

handler.help = ['broadcast <mesej>', 'bc <mesej>']
handler.tags = ['owner']
handler.command = /^(broadcast|bc)$/i
handler.owner = true
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false
handler.admin = false
handler.botAdmin = false
handler.fail = null

module.exports = handler

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms))
}
