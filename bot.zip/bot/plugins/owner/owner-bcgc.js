let handler = async (m, { conn, isROwner, text }) => {
    const delay = time => new Promise(res => setTimeout(res, time))
    let getGroups = await conn.groupFetchAllParticipating()
    let groups = Object.entries(getGroups).slice(0).map(entry => entry[1])
    let anu = groups.map(v => v.id)
    var pesan = m.quoted && m.quoted.text ? m.quoted.text : text
    if (!pesan) throw 'Mesejnya mana?'
    m.reply(`Menghantar Broadcast ke ${anu.length} kumpulan, Masa selesai lebih kurang ${anu.length * 0.5} saat`)
    for (let i of anu) {
        await delay(500)
        conn.sendMessage(i, {
            image: { url: 'https://a.top4top.io/p_37802zcmd1.png' },
            caption: pesan
        }).catch(_ => _)
    }
    m.reply(`Berjaya menghantar broadcast ke ${anu.length} kumpulan`)
}
handler.help = ['bcgcbot <teks>']
handler.tags = ['owner']
handler.command = /^((broadcastgc|bcgc)bot)$/i
handler.owner = true

module.exports = handler
