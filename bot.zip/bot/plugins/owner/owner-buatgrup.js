let handler = async (m, { conn, text, command, usedPrefix }) => {
  if (!text) throw `Format salah!\n\nContoh:\n${usedPrefix + command} NamaKumpulan|@user1 @user2\n\natau boleh juga:\n${usedPrefix + command} NamaKumpulan`
  let [namagc, partText] = text.split('|').map(s => s.trim())
  if (!namagc) throw 'Nama kumpulan tak boleh kosong!'

  let peserta = [m.sender]

  if (partText) {
    let mentions = conn.parseMention(partText)
    if (mentions.length > 0) {
      peserta = [...new Set([...peserta, ...mentions])]
    }
  }

  const group = await conn.groupCreate(namagc, peserta)
  const link = 'https://chat.whatsapp.com/' + await conn.groupInviteCode(group.id)

  await conn.sendMessage(group.id, {
    text: `Hai semua! Kumpulan ini dibuat oleh @${m.sender.split('@')[0]}`,
    mentions: [m.sender]
  })

  m.reply(`*Kumpulan berjaya dibuat!*\n\nNama: *${namagc}*\nPautan: ${link}`, null, {
    mentions: [m.sender]
  })
}

handler.help = ['buatgrup']
handler.tags = ['owner']
handler.command = /^buatgrup$/i
handler.owner = true

module.exports = handler
