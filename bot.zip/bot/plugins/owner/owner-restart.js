let handler = async (m, { conn }) => {
  if (!process.send) throw '❌ Jalankan bot dengan: *node index.js*\nbukan: node main.js'
  if (global.conn.user.jid == conn.user.jid) {
    await m.reply('🔄 *VynaaMD sedang dimulakan semula...*\n\nSila tunggu lebih kurang 1 minit 🙏\n\n> _© VynaaMD by VynaaValerie_')
    process.send('reset')
  } else throw '❌ Tidak boleh mulakan semula dari sambungan ini!'
}

handler.help = ['restart']
handler.tags = ['owner']
handler.command = /^(srvrestart|restart)$/i
handler.rowner = true

module.exports = handler
