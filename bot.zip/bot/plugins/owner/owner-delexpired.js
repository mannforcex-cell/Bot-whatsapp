let handler = async (m, { conn, args, usedPrefix, command }) => {

    let who
    if (m.isGroup) who = args[0] ? args[0] : m.chat
    else who = args[0]

    if (new Date() * 1 < global.db.data.chats[who].expired) global.db.data.chats[who].expired = false
    else global.db.data.chats[who].expired = false
    conn.reply(m.chat, `Berjaya memadamkan hari tamat tempoh untuk Kumpulan ini`, m)
}
handler.help = ['delsewa']
handler.tags = ['owner']
handler.command = /^(delexpired|delsewa)$/i
handler.rowner = true

module.exports = handler

function msToDate(ms) {
    let temp = ms
    let days = Math.floor(ms / (24 * 60 * 60 * 1000));
    let daysms = ms % (24 * 60 * 60 * 1000);
    let hours = Math.floor((daysms) / (60 * 60 * 1000));
    let hoursms = ms % (60 * 60 * 1000);
    let minutes = Math.floor((hoursms) / (60 * 1000));
    return days + " hari " + hours + " jam " + minutes + " minit";
}
