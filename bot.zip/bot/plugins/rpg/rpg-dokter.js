const STATES = {
  IDLE: 0,
  SEARCHING: 1,
  FIGHTING: 2,
};

function getRandomInt(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

const handler = async (m, { conn, usedPrefix, command, args }) => {
  const sender = m.sender;
  const user = global.db.data.users[sender]
  conn.playerr = conn.playerr || {};
  const player = conn.playerr[sender] || { Balance: 0, Pasien_Sembuh: 0, Waktu_Sembuh: 0, Obat_Super: 0, Lv: 1, State: STATES.IDLE };

  if (command === "dokter") {
    if (args.length === 0) {
      conn.sendMessage(m.chat, {
        image: { url: 'https://a.top4top.io/p_37802zcmd1.png' },
        caption: "*👨‍⚕ Cara Bermain Game Doktor Dan Pesakit 👨‍⚕*\n\n" +
          "🔍 Guna arahan *.dokter cari* untuk mencari pesakit secara rawak.\n" +
          "🚑 Awak akan menjumpai pesakit dan perlu melakukan tindakan tertentu untuk menyembuhkannya.\n" +
          "💰 Awak akan mendapat ganjaran jika berjaya menyembuhkan pesakit.\n" +
          "💉 Pilih tindakan dari: beriobat, rawat, suntik dan operasi.\n" +
          "🔍 Guna arahan *.dokter <tindakan>* untuk merawat dan menyembuhkan pesakit.\n" +
          "🔎 Awak boleh membeli ubat super *.dokter item obat-super* untuk meningkatkan peluang menyembuhkan pesakit.\n" +
          "🏆 Semak kedudukan awak dengan arahan *.dokter leaderboard*.\n" +
          "ℹ️ Guna arahan *.dokter status* untuk melihat status awak sekarang."
      }, { quoted: m });
      return;
    }

    const subCommand = args[0];
    if (subCommand === "cari") {
      if (player.State !== STATES.IDLE) {
        return conn.reply(m.chat, "*🔍 Sedang dalam pencarian...*", m);
      }

      if (Date.now() - player.Waktu_Sembuh < 30000) {
        return conn.reply(m.chat, "*⏱️ Awak perlu menunggu sebentar sebelum boleh mencari semula.*", m);
      }

      player.State = STATES.SEARCHING;
      player.Waktu_Sembuh = Date.now();

      const level = player.Lv;
      const thiefActions = {
        1: "beriobat",
        2: "rawat",
        3: "suntik",
        4: "operasi",
      };
      const thiefAction = thiefActions[level];

      conn.reply(m.chat, `*🔍 Awak menjumpai pesakit tahap ${level}!* Untuk menyembuhkan pesakit, lakukan tindakan: *${thiefAction.toUpperCase()}*.`, m);

      player.ThiefAction = thiefAction;
    } else if (subCommand === "status") {
      conn.reply(m.chat, `*👨‍⚕ Status Doktor 👨‍⚕*\n\n🔍 Sedang Mencari Pesakit: ${player.State === STATES.SEARCHING ? "Ya" : "Tidak"}\n🚑 Pesakit Sembuh: ${player.Pasien_Sembuh}\n💰 Baki: RM${player.Balance.toLocaleString()}\n🏆 Tahap Pesakit: ${player.Lv}`, m);
    } else if (subCommand === "item") {
      if (args.length === 1) {
        conn.reply(m.chat, "*🛒 Kedai Item 🛒*\n\nUbat Super - 500 coins\n" +
          `Guna *${usedPrefix}dokter item obat-super* untuk membeli ubat super.`, m);
      } else {
        const item = args[1]?.toLowerCase();
        if (item === "obat-super") {
          if (player.Obat_Super) {
            return conn.reply(m.chat, "*🛒 Awak sudah mempunyai ubat super.*", m);
          }

          if (player.Balance < 500) {
            return conn.reply(m.chat, "*🛒 Baki awak tidak mencukupi untuk membeli ubat super.*", m);
          }

          player.Obat_Super = 1;
          player.Balance -= 500;
          conn.reply(m.chat, "*🛒 Awak berjaya membeli ubat super.* Guna '.dokter cari' untuk meningkatkan peluang menyembuhkan pesakit.", m);
        } else {
          conn.reply(m.chat, "*🛒 Item yang dimaksudkan tidak dijumpai.*", m);
        }
      }
    } else if (subCommand === "leaderboard") {
      const leaderboard = Object.entries(conn.playerr)
        .map(([playerId, playerData]) => ({ id: playerId, Pasien_Sembuh: playerData.Pasien_Sembuh }))
        .sort((a, b) => b.Pasien_Sembuh - a.Pasien_Sembuh)
        .slice(0, 5);

      let leaderboardMsg = "*🏆 Papan Pendahulu 🏆*\n\n";
      for (let i = 0; i < leaderboard.length; i++) {
        leaderboardMsg += `${i + 1}. @${leaderboard[i].id.split("@")[0]} - ${leaderboard[i].Pasien_Sembuh} Pesakit Sembuh\n`;
      }

      conn.reply(m.chat, leaderboardMsg, m);
    } else if (subCommand === "stop") {
    user.money += player.Balance * player.Pasien_Sembuh;
      let skorMsg = `*🏆 Skor Akhir Awak 🏆*\n\n🚑 Pesakit Sembuh: ${player.Pasien_Sembuh}\n💰 Jumlah Baki: RM${player.Balance.toLocaleString()}\n🏆 Tahap Pesakit: ${player.Lv}`;

      conn.reply(m.chat, `*👨‍⚕ Sesi permainan Doktor dan Pesakit telah dihentikan.*\n\n${skorMsg}`, m);
      player.State = STATES.IDLE;
      player.ThiefAction = undefined;
    } else {
      if (player.State !== STATES.SEARCHING) {
        return conn.reply(m.chat, "*🔍 Awak perlu mencari pesakit terlebih dahulu dengan arahan '.dokter cari'.*", m);
      }

      const dokterAction = subCommand.toLowerCase();
      const level = player.Lv;
      const thiefActions = {
        1: ["beriobat", "rawat", "suntik"],
        2: ["rawat", "operasi"],
        3: ["operasi"],
      };

      if (!thiefActions[level].includes(dokterAction)) {
        return conn.reply(m.chat, `*🚑 Pilihan tindakan awak (${dokterAction.toUpperCase()}) tidak sesuai dengan apa yang diperlukan.*`, m);
      }

      if (thiefActions[level].includes(player.ThiefAction)) {
        let reward = 0;
        switch (dokterAction) {
          case "beriobat":
            reward = 1000 * level;
            break;
          case "rawat":
            reward = 2000 * level;
            break;
          case "suntik":
            reward = 3000 * level;
            break;
          case "operasi":
            reward = 5000 * level;
            break;
        }

        player.Pasien_Sembuh++;
        player.Balance += reward;
        user.money += reward;
        if (player.Balance < 5000) {
          player.Balance = 5000;
        }

        conn.reply(m.chat, `*🚑 Awak berjaya merawat dan menyembuhkan pesakit tahap ${level}!* Awak mendapat ganjaran RM${reward.toLocaleString()}. Jumlah Baki Awak: RM${player.Balance.toLocaleString()}.`, m);
      } else {
        conn.reply(m.chat, "*🚑 Tindakan awak tidak tepat dan pesakit meninggal dunia!*", m);
      }

      player.State = STATES.IDLE;
      player.ThiefAction = undefined;
    }

    conn.playerr[sender] = player;
  } else if (command === "info") {
    conn.reply(m.chat, "*ℹ️ Guna arahan '.dokter' untuk memulakan game Doktor dan Pesakit.*", m);
  }
};

handler.help = ["dokter", "dokter cari", "dokter status", "dokter item <item>", "dokter leaderboard", "dokter stop"];
handler.tags = ["rpg"];
handler.group = true;
handler.command = ["dokter"];
handler.rpg = true

module.exports = handler;
