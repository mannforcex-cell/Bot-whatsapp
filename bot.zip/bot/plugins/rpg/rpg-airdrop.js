let fetch = require('node-fetch');
let fs = require('fs');

let timeout = 3600000

let handler = async (m, { conn, args, usedPrefix, DevMode }) => {

    let u = global.db.data.users[m.sender];
    let time = u.lastclaim + 3600000;
    if (new Date - u.lastclaim < 3600000) throw `*Sudah Mencari Airdrop!* 🪙\nPerlu menunggu untuk boleh mencari Airdrop semula selama ${clockString(time - new Date())}`;
    let Aku = `${Math.floor(Math.random() * 101)}`.trim();
    let Kamu = `${Math.floor(Math.random() * 81)}`.trim();
    let A = (Aku * 1);
    let K = (Kamu * 1);

    if (A > K) {
      let _sampah = Array.from({length: 50}, (_, i) => (i + 1).toString());
      let sampah = _sampah[Math.floor(Math.random() * _sampah.length)];
      let kayu = _sampah[Math.floor(Math.random() * _sampah.length)];
      let batu = _sampah[Math.floor(Math.random() * _sampah.length)];
      conn.sendFile(m.chat, 'https://a.top4top.io/p_37802zcmd1.png', 'zonk.jpg', `*Airdrop Hampa!* Rupanya isinya tidak seperti yang diharapkan\n\n*Ganjaran*\n• *Sampah:* ${sampah}\n• *Kayu:* ${kayu}\n• *Batu:* ${batu}`, m);
      u.sampah += parseInt(sampah);
      u.kayu += parseInt(kayu);
      u.batu += parseInt(batu);
      u.lastclaim = new Date * 1;
    } else if (A < K) {
      let _limit = ['10', '20', '30'];
      let limit = _limit[Math.floor(Math.random() * _limit.length)];
      let _money = ['10000', '100000', '500000'];
      let money = _money[Math.floor(Math.random() * _money.length)];
      let _point = ['10000', '100000', '500000'];
      let point = _point[Math.floor(Math.random() * _point.length)];
      conn.sendFile(m.chat, 'https://a.top4top.io/p_37802zcmd1.png', 'rare.jpg', `*Airdrop Rare!*, Awak mendapat Kotak Airdrop *Rare*\n\nTahniah awak mendapat *Ganjaran*\n• *Had:* ${limit}\n• *Wang:* ${money}\n• *Poin:* ${point}`, m);
      u.limit += parseInt(limit);
      u.money += parseInt(money);
      u.poin += parseInt(point);
      u.lastclaim = new Date * 1;
    } else {
      conn.sendFile(m.chat, 'https://a.top4top.io/p_37802zcmd1.png', 'zonk.jpg', `*Airdrop Zonk!*, Awak mendapat Kotak Airdrop *Zonk (Kosong)*\n\nTahniah awak mendapat *Ganjaran*\n• *Wang:* -1.000.000\n• *Isi:* Angin`, m);
      u.money -= 1000000;
      u.lastclaim = new Date * 1;
    }
};

handler.help = ['airdrop'];
handler.tags = ['rpg'];
handler.command = /^(airdrop)$/i;
handler.group = true;
handler.rpg = true
module.exports = handler;

function pickRandom(list) {
  return list[Math.floor(Math.random() * list.length)];
}

function clockString(ms) {
  let d = isNaN(ms) ? '--' : Math.floor(ms / 86400000);
  let h = isNaN(ms) ? '--' : Math.floor(ms / 3600000) % 24;
  let m = isNaN(ms) ? '--' : Math.floor(ms / 60000) % 60;
  let s = isNaN(ms) ? '--' : Math.floor(ms / 1000) % 60;
  return ['\n*' + d + '* _Hari_ ☀️\n ', '*' + h + '* _Jam_ 🕐\n ', '*' + m + '* _Minit_ ⏰\n ', '*' + s + '* _Saat_ ⏱️ '].map(v => v.toString().padStart(2, 0)).join('');
}
