let handler = async (m, { conn, command }) => {
    let user = global.db.data.users[m.sender]
    let randomaku = Math.floor(Math.random() * 150)
    let randomkamu = Math.floor(Math.random() * 75) //biar sering ke tangkap wkwk
    let __timers = (new Date - user.lastbansos)
    let _timers = (3600000 - __timers) 
    let timers = clockString(_timers)
    if (user.money < 5000000) return m.reply(`Uang Anda Harus Diatas 5Juta Untuk Menggunakan Command Ini`)
    if (new Date - user.lastbansos > 300000) {
      if (randomaku > randomkamu) {
        conn.sendFile(m.chat, 'https://a.top4top.io/p_37802zcmd1.png', 'korupsi.jpg', `Kamu Tertangkap Setelah Kamu korupsi dana bansos🕴️💰,  Dan Kamu harus membayar denda 5 Juta rupiah💵`, m)
        user.money -= 5000000
        user.lastbansos = new Date * 1
      } else if (randomaku < randomkamu) {
        user.money += 5000000
        conn.sendFile(m.chat, 'https://a.top4top.io/p_37802zcmd1.png', 'korupsi.jpg', `Kamu berjaya  korupsi dana bansos🕴️💰,  Dan Kamu mendapatkan 5 Juta rupiah💵`, m)
        user.lastbansos = new Date * 1
      } else {
        m.reply(`Sorry Gan Lu g Berjaya Korupsi bansos Dan Tidak masuk penjara karna Kamu *melarikan diri🏃*`)
        user.lastbansos = new Date * 1
      }
    } else m.reply(`sila Menunggu ${timers} Untuk ${command} Lagi`)
}

handler.help = ['korupsi']
handler.tags = ['rpg']
handler.command = /^(bansos|korupsi)$/i
handler.register = true
handler.group = true
handler.rpg = true

module.exports = handler

function pickRandom(list) {
    return list[Math.floor(Math.random() * list.length)]
}

function clockString(ms) {
  let h = Math.floor(ms / 3600000)
  let m = Math.floor(ms / 60000) % 60
  let s = Math.floor(ms / 1000) % 60
  return [h, m, s].map(v => v.toString().padStart(2, 0) ).join(':')
}