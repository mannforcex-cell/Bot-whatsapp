#!/bin/bash

echo ""
echo "╔══════════════════════════════════╗"
echo "║   VynaaMD Bot — Setup Termux     ║"
echo "║      by VynaaValerie 🌸           ║"
echo "╚══════════════════════════════════╝"
echo ""

# ─── LANGKAH 1: Update Termux ───────────────────────────────
echo "🔄 [1/5] Update pakej Termux..."
pkg update -y && pkg upgrade -y

# ─── LANGKAH 2: Install pakej sistem yang diperlukan ────────
echo ""
echo "📦 [2/5] Install pakej sistem (Node.js, ffmpeg, git)..."
pkg install -y nodejs ffmpeg git python libjpeg-turbo libpng

echo ""
if command -v node &> /dev/null; then
  echo "✅ Node.js $(node -v) berjaya dipasang"
else
  echo "❌ Node.js gagal dipasang. Cuba: pkg install nodejs -y"
  exit 1
fi

if command -v ffmpeg &> /dev/null; then
  echo "✅ ffmpeg berjaya dipasang"
else
  echo "⚠️  ffmpeg gagal — fungsi video/audio mungkin tak berfungsi"
fi

# ─── LANGKAH 3: Install npm pakej ───────────────────────────
echo ""
echo "📦 [3/5] Install npm pakej bot... (5-10 minit)"
echo ""

npm install --legacy-peer-deps

if [ $? -ne 0 ]; then
  echo ""
  echo "⚠️  Cuba cara kedua..."
  npm install --force
fi

# ─── LANGKAH 4: Buat folder yang diperlukan ─────────────────
echo ""
echo "📁 [4/5] Buat folder yang diperlukan..."
mkdir -p tmp sessions media

# ─── LANGKAH 5: Semak sessions ──────────────────────────────
echo ""
echo "🔐 [5/5] Semak sessions..."
if [ -f "sessions/creds.json" ]; then
  echo "✅ Session dijumpai — bot akan terus online TANPA pairing!"
else
  echo "⚠️  Tiada session — awak perlu masukkan Pairing Code bila bot start"
  echo "   (Masukkan nombor telefon > Scan kod dalam WhatsApp > Peranti Tertaut)"
fi

# ─── SELESAI ────────────────────────────────────────────────
echo ""
echo "════════════════════════════════════════"
echo "  ✅ Setup selesai!"
echo ""
echo "  ▶  Jalankan bot:"
echo "     node index.termux.js"
echo ""
echo "  ▶  Jalankan di background (tak tutup):"
echo "     pkg install screen -y"
echo "     screen -S bot"
echo "     node index.termux.js"
echo "     (Ctrl+A lalu D untuk minimize)"
echo ""
echo "  ▶  Nak guna session dari Replit?"
echo "     Salin fail sessions/creds.json"
echo "     ke folder sessions/ — tak perlu pair semula!"
echo "════════════════════════════════════════"
echo ""
